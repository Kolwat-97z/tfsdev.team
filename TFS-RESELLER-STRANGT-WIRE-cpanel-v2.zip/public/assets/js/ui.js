/* Shared UI primitives: icons, formatting, toasts, modal, drawer, charts. */

export const esc = (value) =>
  String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export const icon = (name, cls = 'ico') => `<svg class="${cls}" aria-hidden="true"><use href="#i-${name}"/></svg>`;

export const fmtNum = (n) => new Intl.NumberFormat('en-US').format(Number(n) || 0);

export function fmtDate(ts) {
  if (!ts) return '—';
  return new Date(ts).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function fmtDateTime(ts) {
  if (!ts) return '—';
  return new Date(ts).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
}

export function fmtRelative(ts) {
  if (!ts) return 'never';
  const diff = Date.now() - ts;
  const abs = Math.abs(diff);
  const units = [
    [60000, 1000, 'sec'], [3600000, 60000, 'min'], [86400000, 3600000, 'hr'],
    [2592000000, 86400000, 'day'], [31536000000, 2592000000, 'mo'], [Infinity, 31536000000, 'yr']
  ];
  for (const [limit, ms, label] of units) {
    if (abs < limit) {
      const v = Math.max(1, Math.round(abs / ms));
      const text = `${v} ${label}${v === 1 ? '' : 's'}`;
      return diff >= 0 ? `${text} ago` : `in ${text}`;
    }
  }
  return '—';
}

export function daysLeft(ts) {
  if (!ts) return null;
  return Math.ceil((ts - Date.now()) / 86400000);
}

export function badge(status, label) {
  return `<span class="badge ${esc(status)}">${esc(label ?? status)}</span>`;
}

export function toast(message, tone = 'info') {
  const host = document.getElementById('toasts');
  const node = document.createElement('div');
  node.className = `toast ${tone}`;
  node.textContent = message;
  host.appendChild(node);
  setTimeout(() => {
    node.classList.add('out');
    setTimeout(() => node.remove(), 220);
  }, 3200);
}

/* ---------- modal ---------- */
export function openModal({ title, subtitle = '', body = '', footer = '', wide = false, onMount }) {
  const root = document.getElementById('modal-root');
  root.innerHTML = `
    <div class="modal" id="modal" aria-hidden="false" role="dialog" aria-modal="true">
      <div class="modal-card ${wide ? 'wide' : ''}">
        ${title ? `<div class="dlg-head"><div><h3>${esc(title)}</h3>${subtitle ? `<p class="card-sub">${esc(subtitle)}</p>` : ''}</div><button class="ghost icon" data-close aria-label="Close">✕</button></div>` : ''}
        <div class="dlg-body">${body}</div>
        ${footer ? `<div class="modal-foot">${footer}</div>` : ''}
      </div>
    </div>`;
  const modal = root.querySelector('.modal');
  const close = () => closeModal();
  modal.addEventListener('click', (event) => { if (event.target === modal) close(); });
  modal.querySelectorAll('[data-close]').forEach((btn) => btn.addEventListener('click', close));
  document.addEventListener('keydown', escHandler);
  function escHandler(event) {
    if (event.key === 'Escape') { close(); }
  }
  if (onMount) onMount(modal, close);
  return { modal, close };
}

export function closeModal() {
  document.getElementById('modal-root').innerHTML = '';
}

export function confirmDialog({ title, message, confirmLabel = 'Confirm', danger = false }) {
  return new Promise((resolve) => {
    const { close } = openModal({
      title,
      body: `<p>${esc(message)}</p>`,
      footer: `<button class="ghost" data-cancel>Cancel</button><button class="${danger ? 'grad-btn' : 'grad-btn'}" data-ok>${esc(confirmLabel)}</button>`,
      onMount(modal) {
        modal.querySelector('[data-cancel]').addEventListener('click', () => { close(); resolve(false); });
        modal.querySelector('[data-ok]').addEventListener('click', () => { close(); resolve(true); });
      }
    });
  });
}

/* ---------- drawer ---------- */
export function openDrawer(title, html) {
  document.getElementById('drawer-key').textContent = title;
  document.getElementById('drawer-body').innerHTML = html;
  document.getElementById('drawer').setAttribute('aria-hidden', 'false');
}

export function closeDrawer() {
  document.getElementById('drawer').setAttribute('aria-hidden', 'true');
}

/* ---------- clipboard ---------- */
export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    toast('Copied to clipboard', 'ok');
  } catch {
    const area = document.createElement('textarea');
    area.value = text;
    document.body.appendChild(area);
    area.select();
    document.execCommand('copy');
    area.remove();
    toast('Copied to clipboard', 'ok');
  }
}

/* ---------- charts ---------- */
export function sparkline(values, width = 120, height = 44) {
  const max = Math.max(...values, 1);
  const min = Math.min(...values, 0);
  const stepX = width / Math.max(values.length - 1, 1);
  const points = values.map((v, i) => {
    const x = i * stepX;
    const y = height - ((v - min) / Math.max(max - min, 1)) * (height - 8) - 4;
    return [x, y];
  });
  const line = points.map(([x, y], i) => `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  const area = `${line} L${width},${height} L0,${height} Z`;
  return `<svg class="spark" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" aria-hidden="true">
    <path class="area" d="${area}"/><path class="ln" d="${line}"/></svg>`;
}

export function areaChart(values, labels) {
  const w = 640;
  const h = 220;
  const pad = { l: 34, r: 12, t: 14, b: 24 };
  const max = Math.max(...values, 1);
  const top = Math.ceil(max / 20) * 20;
  const stepX = (w - pad.l - pad.r) / Math.max(values.length - 1, 1);
  const yFor = (v) => pad.t + (h - pad.t - pad.b) * (1 - v / top);
  const pts = values.map((v, i) => [pad.l + i * stepX, yFor(v)]);
  const line = pts.map(([x, y], i) => `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  const area = `${line} L${(pad.l + (values.length - 1) * stepX).toFixed(1)},${h - pad.b} L${pad.l},${h - pad.b} Z`;
  const gridLines = [0, 0.25, 0.5, 0.75, 1].map((f) => {
    const y = pad.t + (h - pad.t - pad.b) * f;
    const val = Math.round(top * (1 - f));
    return `<line class="grid-l" x1="${pad.l}" y1="${y}" x2="${w - pad.r}" y2="${y}"/>
      <text class="ax" x="${pad.l - 8}" y="${y + 3.5}" text-anchor="end">${val}</text>`;
  }).join('');
  const xLabels = labels.map((label, i) => {
    if (i % Math.ceil(labels.length / 7) !== 0 && i !== labels.length - 1) return '';
    return `<text class="ax" x="${(pad.l + i * stepX).toFixed(1)}" y="${h - 6}" text-anchor="middle">${esc(label)}</text>`;
  }).join('');
  return `<svg class="area-chart" viewBox="0 0 ${w} ${h}" role="img" aria-label="Licenses created over time">
    <defs><linearGradient id="areaFill" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="var(--accent)" stop-opacity=".28"/>
      <stop offset="100%" stop-color="var(--accent)" stop-opacity="0"/>
    </linearGradient></defs>
    ${gridLines}${xLabels}
    <path class="fill" d="${area}" fill="url(#areaFill)"/>
    <path class="stroke" d="${line}"/>
    ${pts.map(([x, y], i) => `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="2.6" fill="var(--card-hi)" stroke="var(--accent)" stroke-width="2" opacity="${i === pts.length - 1 ? 1 : 0}"/>`).join('')}
  </svg>`;
}

export function donutChart(segments, total, centerLabel = 'licenses') {
  const size = 148;
  const r = 62;
  const c = 2 * Math.PI * r;
  let offset = 0;
  const rings = segments.map((seg) => {
    const frac = total ? seg.value / total : 0;
    const dash = `${(frac * c).toFixed(2)} ${c.toFixed(2)}`;
    const circle = `<circle cx="${size / 2}" cy="${size / 2}" r="${r}" stroke="${seg.color}" stroke-dasharray="${dash}" stroke-dashoffset="${(-offset * c).toFixed(2)}" stroke-linecap="butt"><title>${esc(seg.label)}: ${seg.value}</title></circle>`;
    offset += frac;
    return circle;
  }).join('');
  return `<div class="donut">
    <svg viewBox="0 0 ${size} ${size}"><circle class="track" cx="${size / 2}" cy="${size / 2}" r="${r}"/>${rings}</svg>
    <div class="donut-c"><b>${fmtNum(total)}</b><span>${esc(centerLabel)}</span></div>
  </div>`;
}

export function emptyRow(text) {
  return `<li class="empty-row">${esc(text)}</li>`;
}
