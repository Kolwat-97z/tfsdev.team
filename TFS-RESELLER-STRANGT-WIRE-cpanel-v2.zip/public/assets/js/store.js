/* Data store: seeded sample data + session, persisted to localStorage. */

const DATA_KEY = 'sw.admin.data.v2';
const SESSION_KEY = 'sw.admin.session.v2';
const THEME_KEY = 'sw.admin.theme.v2';

/* Deterministic PRNG so the demo dataset is stable between reloads. */
function mulberry32(seed) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rand = mulberry32(20261119);
const pick = (list) => list[Math.floor(rand() * list.length)];
const int = (min, max) => Math.floor(rand() * (max - min + 1)) + min;
const DAY = 86400000;

const CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const block = (n) => Array.from({ length: n }, () => CHARS[Math.floor(rand() * CHARS.length)]).join('');
const keyString = () => `SW-${block(4)}-${block(4)}-${block(4)}`;
const hwidString = () => Array.from({ length: 4 }, () => block(4)).join('-');

const NOTES = [
  'Reseller A · order #1042', 'Reseller B · order #1188', 'Direct sale', 'Trial request',
  'Promo — Discord event', 'Reseller A · bulk batch', 'Chargeback hold', 'Renewal #2210',
  'Giveaway winner', 'Store checkout', ''
];
const CREATORS = ['admin', 'maya', 'dealerbot'];
const TAGS = ['vip', 'reseller', 'trial', 'promo'];
const SERVERS = ['EU-West', 'EU-Central', 'NA-East', 'NA-West', 'AP-South'];
const DURATIONS = [
  { label: '7 days', seconds: 7 * 86400 },
  { label: '30 days', seconds: 30 * 86400 },
  { label: '90 days', seconds: 90 * 86400 },
  { label: '180 days', seconds: 180 * 86400 },
  { label: '365 days', seconds: 365 * 86400 }
];

const now = Date.now();

function makeKeys(count) {
  const keys = [];
  for (let i = 0; i < count; i += 1) {
    const roll = rand();
    let status = 'active';
    if (roll > 0.955) status = 'banned';
    else if (roll > 0.90) status = 'disabled';
    else if (roll > 0.80) status = 'expired';
    else if (roll > 0.755) status = 'lifetime';

    const duration = status === 'lifetime' ? null : pick(DURATIONS).seconds;
    const createdOffset = int(1, 88) * DAY + int(0, 23) * 3600000;
    const createdAt = now - createdOffset;
    let expiresAt = duration ? createdAt + duration * 1000 : null;
    if (status === 'expired') expiresAt = now - int(1, 20) * DAY;

    const maxDevices = int(1, 4);
    const devices = status === 'active' ? int(0, maxDevices) : int(0, Math.max(0, maxDevices - 1));
    const tags = rand() > 0.72 ? [pick(TAGS)] : [];

    keys.push({
      id: `k_${i + 1}`,
      key: keyString(),
      status,
      duration,
      maxDevices,
      devices,
      hwid: devices > 0 ? hwidString() : '',
      createdAt,
      expiresAt,
      note: pick(NOTES),
      createdBy: pick(CREATORS),
      tags,
      lastSeen: devices > 0 ? now - int(0, 12) * DAY : null,
      server: pick(SERVERS)
    });
  }
  /* A few deliberate rows so the dashboard lists always have content. */
  keys[0] = { ...keys[0], status: 'active', devices: 2, maxDevices: 3, hwid: hwidString(), expiresAt: now + 2 * DAY, tags: ['vip'], note: 'Reseller A · order #1042', lastSeen: now - 42 * 60000 };
  keys[1] = { ...keys[1], status: 'active', devices: 1, maxDevices: 1, hwid: hwidString(), expiresAt: now + 5 * DAY, tags: ['reseller'], note: 'Reseller B · order #1188', lastSeen: now - 3 * 3600000 };
  keys[2] = { ...keys[2], status: 'lifetime', duration: null, expiresAt: null, devices: 1, maxDevices: 2, hwid: hwidString(), note: 'Giveaway winner', tags: ['vip'] };
  keys[3] = { ...keys[3], status: 'active', devices: 0, maxDevices: 1, hwid: '', expiresAt: now + 6 * DAY, note: 'Store checkout', tags: [] };
  return keys;
}

const KEYS = makeKeys(64);

const DEVICES = KEYS.filter((k) => k.devices > 0)
  .slice(0, 14)
  .map((k, i) => ({
    id: `d_${i + 1}`,
    hwid: k.hwid,
    key: k.key,
    server: k.server,
    bound: now - int(2, 60) * DAY,
    lastSeen: now - int(0, 96) * 3600000,
    profile: `profile_${block(6).toLowerCase()}`
  }));

const API_KEYS = [
  { id: 'ak_1', name: 'Reseller A', key: `sw_live_${block(28).toLowerCase()}`, status: 'active', createdAt: now - 41 * DAY, lastUsed: now - 2 * 3600000, calls: 12840 },
  { id: 'ak_2', name: 'Reseller B', key: `sw_live_${block(28).toLowerCase()}`, status: 'active', createdAt: now - 27 * DAY, lastUsed: now - 26 * 3600000, calls: 4211 },
  { id: 'ak_3', name: 'Legacy storefront', key: `sw_live_${block(28).toLowerCase()}`, status: 'disabled', createdAt: now - 88 * DAY, lastUsed: now - 19 * DAY, calls: 902 }
];

const ENDPOINTS = [
  { method: 'POST', path: '/v1/license/create', params: '{"duration":2592000,"devices":2,"note":"order #1024"}', desc: 'Create one or more license keys' },
  { method: 'POST', path: '/v1/license/verify', params: '{"key":"SW-…","hwid":"…"}', desc: 'Validate a key and bind the device' },
  { method: 'POST', path: '/v1/license/renew', params: '{"key":"SW-…","duration":2592000}', desc: 'Extend an existing key' },
  { method: 'GET', path: '/v1/license/info', params: '{"key":"SW-…"}', desc: 'Read status, expiry and device usage' },
  { method: 'POST', path: '/v1/license/reset-hwid', params: '{"key":"SW-…"}', desc: 'Clear bound devices for a key' },
  { method: 'POST', path: '/v1/license/ban', params: '{"key":"SW-…","reason":"chargeback"}', desc: 'Ban a key and burn its profiles' },
  { method: 'GET', path: '/v1/keys/export', params: '{"status":"active","limit":100}', desc: 'Export keys as JSON' }
];

const ADMINS = [
  { id: 'u_1', user: 'tfs', name: 'tfs', email: 'owner@strangewire.cc', role: 'owner', password: 'tfs-pass', credits: null, apiKey: null, twofa: true, status: 'active', lastLogin: now - 12 * 60000 },
  { id: 'u_2', user: 'maya', name: 'Maya Chen', email: 'maya@strangewire.cc', role: 'reseller', password: 'maya-pass', credits: 480, apiKey: `az_${block(40).toLowerCase()}`, twofa: true, status: 'active', lastLogin: now - 5 * 3600000 },
  { id: 'u_3', user: 'dealerbot', name: 'Dealer Bot', email: 'ops@reseller-a.com', role: 'reseller_vip', password: 'dealer-pass', credits: null, apiKey: `az_${block(40).toLowerCase()}`, twofa: false, status: 'active', lastLogin: now - 2 * DAY },
  { id: 'u_4', user: 'support', name: 'Support Desk', email: 'help@strangewire.cc', role: 'admin', password: 'support-pass', credits: null, apiKey: null, twofa: false, status: 'suspended', lastLogin: now - 21 * DAY }
];

const ACTIONS = [
  ['keys.create', 'key'], ['keys.renew', 'key'], ['keys.ban', 'key'], ['keys.disable', 'key'],
  ['keys.delete', 'key'], ['devices.reset', 'key'], ['api.key.create', 'api'], ['auth.login', 'session'],
  ['settings.update', 'setting'], ['users.create', 'user'], ['control.toggle', 'feature'], ['audit.verify', 'chain']
];

function makeAudit(count) {
  const rows = [];
  for (let i = 0; i < count; i += 1) {
    const [action, kind] = pick(ACTIONS);
    const key = pick(KEYS);
    const actor = pick(['admin', 'admin', 'maya', 'dealerbot']);
    const target =
      kind === 'key' ? key.key :
      kind === 'api' ? pick(API_KEYS).name :
      kind === 'user' ? pick(ADMINS).user :
      kind === 'feature' ? pick(['Aimbot', 'ESP Box', 'Bunnyhop', 'Radar Hack']) :
      kind === 'chain' ? 'audit-log' : 'settings';
    rows.push({
      id: `a_${i + 1}`,
      at: now - i * int(20, 260) * 60000,
      actor,
      role: actor === 'admin' ? 'owner' : actor === 'maya' ? 'admin' : 'moderator',
      action,
      target,
      result: rand() > 0.93 ? 'denied' : 'ok',
      ip: `81.${int(2, 250)}.${int(2, 250)}.${int(2, 250)}`
    });
  }
  return rows;
}

const AUDIT = makeAudit(48);

const FEATURES = {
  basic: [
    ['Aimbot', 'Combat', true], ['Silent Aim', 'Combat', true], ['Trigger Bot', 'Combat', false],
    ['ESP Box', 'Visuals', true], ['Skeleton ESP', 'Visuals', false], ['Distance ESP', 'Visuals', true],
    ['Chams', 'Visuals', false], ['No Flash', 'Visuals', true], ['FOV Changer', 'Visuals', false],
    ['Bunnyhop', 'Movement', true], ['Auto Strafe', 'Movement', false], ['Fast Ladder', 'Movement', true],
    ['Auto Accept', 'Misc', true], ['Anti AFK', 'Misc', true], ['Name Spoofer', 'Misc', false]
  ],
  pro: [
    ['Aimbot', 'Combat', true], ['Silent Aim', 'Combat', true], ['Trigger Bot', 'Combat', true],
    ['ESP Box', 'Visuals', true], ['Skeleton ESP', 'Visuals', true], ['Distance ESP', 'Visuals', true],
    ['Chams', 'Visuals', true], ['No Flash', 'Visuals', true], ['FOV Changer', 'Visuals', true],
    ['Bunnyhop', 'Movement', true], ['Auto Strafe', 'Movement', true], ['Fast Ladder', 'Movement', true],
    ['Auto Accept', 'Misc', true], ['Anti AFK', 'Misc', true], ['Name Spoofer', 'Misc', true],
    ['Radar Hack', 'Misc', false]
  ],
  elite: [
    ['Aimbot', 'Combat', true], ['Silent Aim', 'Combat', true], ['Trigger Bot', 'Combat', true],
    ['ESP Box', 'Visuals', true], ['Skeleton ESP', 'Visuals', true], ['Distance ESP', 'Visuals', true],
    ['Chams', 'Visuals', true], ['No Flash', 'Visuals', true], ['FOV Changer', 'Visuals', true],
    ['Bunnyhop', 'Movement', true], ['Auto Strafe', 'Movement', true], ['Fast Ladder', 'Movement', true],
    ['Auto Accept', 'Misc', true], ['Anti AFK', 'Misc', true], ['Name Spoofer', 'Misc', true],
    ['Radar Hack', 'Misc', true], ['Stream Proof', 'Misc', true]
  ]
};

const FUNCTIONS = [
  ['Aimbot', 'live', 'elite', 'Smoothing and humanised curves'],
  ['Silent Aim', 'live', 'elite', 'Perfect accuracy, no snap'],
  ['ESP Box', 'live', 'basic', '2D boxes with health bars'],
  ['Skeleton ESP', 'live', 'pro', 'Joint overlay'],
  ['Chams', 'maintenance', 'pro', 'Rewriting render hook'],
  ['Radar Hack', 'live', 'elite', 'Full map awareness'],
  ['Bunnyhop', 'live', 'basic', 'Auto jump timing'],
  ['Auto Strafe', 'live', 'pro', ''],
  ['Name Spoofer', 'hidden', 'elite', 'Under review'],
  ['Stream Proof', 'live', 'elite', 'Hidden from capture'],
  ['Anti AFK', 'live', 'basic', ''],
  ['Auto Accept', 'live', 'basic', 'Matchmaking helper'],
  ['No Flash', 'live', 'pro', ''],
  ['FOV Changer', 'maintenance', 'basic', 'Slider rewrite in progress']
].map(([name, state, tier, note], i) => ({ id: `f_${i + 1}`, name, state, tier, note, updated: now - i * 7 * 3600000 }));

const HEALTH = [
  { label: 'Storage', value: 'healthy', tone: 'ok' },
  { label: 'Database', value: 'healthy', tone: 'ok' },
  { label: 'API latency', value: '42 ms', tone: 'ok' },
  { label: 'Audit chain', value: 'verified', tone: 'ok' },
  { label: 'Key pipeline', value: 'degraded', tone: 'warn' },
  { label: 'Backups', value: '4h ago', tone: 'ok' }
];

function defaultState() {
  return {
    settings: {
      theme: 'dark',
      accent: '#b814e8',
      siteTitle: 'Strange Wair',
      supportUrl: 'https://strangewire.authzen.cc/support',
      prefix: 'SW',
      defaultDuration: 30 * 86400,
      defaultDevices: 1,
      maintenance: false,
      maintenanceMessage: 'Scheduled maintenance — back in a few minutes.',
      snowEnabled: false,
      contact: { discordUrl: '', telegramUrl: '' },
      notifications: { discordEnabled: false, discordWebhookUrl: '', telegramEnabled: false, telegramBotToken: '', telegramChatId: '' }
    },
    admin: {
      user: 'tfs',
      name: 'tfs',
      email: 'owner@strangewire.cc',
      role: 'owner',
      password: 'tfs-pass',
      defaultPassword: true,
      twofa: false,
      credits: null,
      apiKey: null
    },
    keys: KEYS,
    sellerOwnership: {},
    creditTransactions: [],
    devices: DEVICES,
    apiKeys: API_KEYS,
    endpoints: ENDPOINTS,
    admins: ADMINS,
    audit: AUDIT,
    features: FEATURES,
    functions: FUNCTIONS,
    health: HEALTH,
    sessions: [
      { id: 's_1', ip: '81.144.22.9', device: 'Chrome · macOS', created: now - 26 * 60000, lastSeen: now - 60000, current: true },
      { id: 's_2', ip: '184.72.108.44', device: 'Firefox · Windows', created: now - 2 * DAY, lastSeen: now - 5 * 3600000, current: false },
      { id: 's_3', ip: '103.21.58.7', device: 'Safari · iPhone', created: now - 6 * DAY, lastSeen: now - 3 * DAY, current: false }
    ]
  };
}

function read(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

export const state = read(DATA_KEY, null) || defaultState();
state.sellerOwnership ||= {};
state.creditTransactions ||= [];
state.settings ||= {};
state.settings.contact ||= { discordUrl: '', telegramUrl: '' };
state.settings.notifications ||= { discordEnabled: false, discordWebhookUrl: '', telegramEnabled: false, telegramBotToken: '', telegramChatId: '' };
if (typeof state.settings.snowEnabled !== 'boolean') state.settings.snowEnabled = false;

/* Upgrade older local demo data without affecting newer credentials. */
if (state.admin?.user === 'admin' && state.admin?.password === 'admin123') {
  state.admin.user = 'tfs';
  state.admin.name = 'tfs';
  state.admin.password = 'tfs-pass';
  state.admin.role = 'owner';
  state.settings.theme = 'dark';
  localStorage.setItem(THEME_KEY, 'dark');
  const owner = state.admins?.find((u) => u.user === 'admin');
  if (owner) { owner.user = 'tfs'; owner.name = 'tfs'; owner.password = 'tfs-pass'; owner.role = 'owner'; }
  save();
}
if (state.admin?.user === 'tfs' && state.settings?.theme === 'light' && localStorage.getItem(THEME_KEY) === 'light') {
  state.settings.theme = 'dark';
  localStorage.setItem(THEME_KEY, 'dark');
  save();
}
if (state.admins) {
  const maya = state.admins.find((u) => u.user === 'maya');
  const dealer = state.admins.find((u) => u.user === 'dealerbot');
  if (maya) { maya.role = 'reseller'; maya.credits ??= 480; if (!maya.apiKeySource) maya.apiKey = null; maya.password ??= 'maya-pass'; }
  if (dealer) { dealer.role = 'reseller_vip'; dealer.credits = null; if (!dealer.apiKeySource) dealer.apiKey = null; dealer.password ??= 'dealer-pass'; }
  save();
}
if (state.admin?.role === 'reseller' || state.admin?.role === 'reseller_vip') {
  const current = state.admins?.find((u) => u.user === state.admin.user);
  if (current && !current.apiKeySource) { state.admin.apiKey = null; save(); }
}

export function save() {
  try {
    localStorage.setItem(DATA_KEY, JSON.stringify(state));
  } catch {
    /* storage full or blocked — the demo still works in memory */
  }
}

export function resetData() {
  const fresh = defaultState();
  Object.keys(state).forEach((k) => { delete state[k]; });
  Object.assign(state, fresh);
  save();
}

/* ---------- session ---------- */
export function getSession() {
  return read(SESSION_KEY, null);
}

export function startSession(user) {
  const session = { user: user.user, role: user.role, name: user.name, startedAt: Date.now() };
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  return session;
}

export function endSession() {
  localStorage.removeItem(SESSION_KEY);
}

/* ---------- theme ---------- */
export function getTheme() {
  return localStorage.getItem(THEME_KEY) || state.settings.theme || 'light';
}

export function setTheme(mode) {
  localStorage.setItem(THEME_KEY, mode);
  state.settings.theme = mode;
  save();
}

/* ---------- helpers ---------- */
export function statusOf(key) {
  if (key.status === 'pending') return 'pending';
  if (key.status === 'lifetime') return 'lifetime';
  if (key.status === 'banned') return 'banned';
  if (key.status === 'disabled') return 'disabled';
  if (key.expiresAt && key.expiresAt < Date.now()) return 'expired';
  return 'active';
}

export function statusCounts(keys = state.keys) {
  const out = { all: keys.length, active: 0, pending: 0, expired: 0, disabled: 0, banned: 0, lifetime: 0 };
  keys.forEach((k) => { out[statusOf(k)] += 1; });
  return out;
}

export function durationLabel(key) {
  if (statusOf(key) === 'lifetime') return 'Lifetime';
  if (!key.duration) return '—';
  const days = Math.round(key.duration / 86400);
  if (days % 365 === 0) return `${days / 365} year${days > 365 ? 's' : ''}`;
  if (days % 30 === 0) return `${days / 30} month${days > 30 ? 's' : ''}`;
  if (days % 7 === 0) return `${days / 7} week${days > 7 ? 's' : ''}`;
  return `${days} day${days === 1 ? '' : 's'}`;
}

export function addAudit(action, target, result = 'ok') {
  state.audit.unshift({
    id: `a_${Date.now()}`,
    at: Date.now(),
    actor: state.admin.user,
    role: state.admin.role,
    action,
    target,
    result,
    ip: '81.144.22.9'
  });
  save();
}

export function makeKey({ mask = 'SW-****-****-****', duration = 30 * 86400, devices = 1, note = '', lifetime = false, custom = '' }) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const render = (template) => template.replace(/\*/g, () => chars[Math.floor(Math.random() * chars.length)]);
  const key = custom.trim() || render(mask || 'SW-****-****-****');
  const createdAt = Date.now();
  const entry = {
    id: `k_${createdAt}_${Math.floor(Math.random() * 999)}`,
    key,
    status: lifetime ? 'lifetime' : 'active',
    duration: lifetime ? null : duration,
    maxDevices: devices,
    devices: 0,
    hwid: '',
    createdAt,
    expiresAt: lifetime ? null : createdAt + duration * 1000,
    note,
    createdBy: state.admin.user,
    tags: [],
    lastSeen: null,
    server: 'EU-West'
  };
  state.keys.unshift(entry);
  save();
  return entry;
}

export function maskKey(key) {
  if (!key) return '—';
  return `${key.slice(0, 7)}…${key.slice(-4)}`;
}

export { DURATIONS };
