/* Licenses: tabs, search syntax, sorting, bulk actions, pagination. */
import { state, save, statusOf, statusCounts, durationLabel, addAudit, maskKey } from '../store.js';
import { icon, esc, fmtDate, fmtDateTime, fmtNum, daysLeft, badge, toast, copyText, openDrawer, confirmDialog, openModal } from '../ui.js';

const view = {
  tab: 'all',
  query: '',
  sort: 'newest',
  perPage: 10,
  page: 1,
  selected: new Set()
};

const SORTS = {
  newest: (a, b) => b.createdAt - a.createdAt,
  oldest: (a, b) => a.createdAt - b.createdAt,
  expiring: (a, b) => (a.expiresAt || Infinity) - (b.expiresAt || Infinity),
  expiry_late: (a, b) => (b.expiresAt || 0) - (a.expiresAt || 0),
  devices: (a, b) => b.devices - a.devices,
  seen: (a, b) => (b.lastSeen || 0) - (a.lastSeen || 0),
  az: (a, b) => a.key.localeCompare(b.key)
};

function matchQuery(key, query) {
  if (!query.trim()) return true;
  const tokens = query.trim().toLowerCase().split(/\s+/);
  return tokens.every((token) => {
    const [rawField, ...rest] = token.split(':');
    const value = rest.join(':');
    if (rest.length) {
      switch (rawField) {
        case 'status': return statusOf(key) === value;
        case 'tag': return key.tags.some((t) => t.toLowerCase() === value);
        case 'device': return key.hwid.toLowerCase().includes(value);
        case 'note': return key.note.toLowerCase().includes(value);
        case 'prefix': return key.key.toLowerCase().startsWith(value);
        case 'devices': return value === 'full' ? key.devices >= key.maxDevices : String(key.devices) === value;
        case 'created': return key.createdBy.toLowerCase().includes(value);
        default: return true;
      }
    }
    if (token === 'lifetime') return statusOf(key) === 'lifetime';
    if (token === 'live') return statusOf(key) === 'active';
    return [key.key, key.note, key.hwid, key.createdBy, ...key.tags].join(' ').toLowerCase().includes(token);
  });
}

export function filtered() {
  const owner = state.admin.role === 'owner';
  return state.keys
    .filter((k) => owner || state.sellerOwnership?.[k.key] === state.admin.user)
    .filter((k) => (view.tab === 'all' ? true : statusOf(k) === view.tab))
    .filter((k) => matchQuery(k, view.query))
    .sort(SORTS[view.sort] || SORTS.newest);
}

export function render() {
  const owner = state.admin.role === 'owner';
  const scopedKeys = owner ? state.keys : state.keys.filter((k) => state.sellerOwnership?.[k.key] === state.admin.user);
  const counts = statusCounts(scopedKeys);
  const rows = filtered();
  const pages = Math.max(1, Math.ceil(rows.length / view.perPage));
  view.page = Math.min(view.page, pages);
  const start = (view.page - 1) * view.perPage;
  const slice = rows.slice(start, start + view.perPage);
  const tabs = [
    ['all', 'All'], ['active', 'Active'], ['pending', 'Unused'], ['expired', 'Expired'],
    ['disabled', 'Disabled'], ['banned', 'Banned'], ['lifetime', 'Lifetime']
  ];

  return `
  <section class="view" data-view="licenses">
    <div class="page-head">
      <div class="tool-actions">
        <button class="ghost" data-act="import">${icon('download')}Import</button>
        <button class="ghost" data-act="export">${icon('file-text')}Export</button>
        <button class="ghost danger" data-act="purge">${icon('trash')}Delete</button>
        <button class="grad-btn" data-action="create-keys">${icon('plus-circle')}Create Keys</button>
      </div>
    </div>

    <div class="section table-card">
      <div class="tabs" id="key-tabs">
        ${tabs.map(([id, label]) => `<button class="tab ${view.tab === id ? 'on' : ''}" data-tab="${id}">${label}<span>${counts[id]}</span></button>`).join('')}
      </div>
      <div class="table-tools">
        <div class="search-inline">
          ${icon('search')}
          <input id="key-search" value="${esc(view.query)}" placeholder="Search key, note, tag, HWID…  (try tag:vip status:active)" aria-label="Search licenses">
        </div>
        <span class="count">${fmtNum(rows.length)} ${rows.length === 1 ? 'key' : 'keys'}</span>
        <select id="key-sort" class="mini" aria-label="Sort licenses">
          ${[['newest', 'Newest first'], ['oldest', 'Oldest first'], ['expiring', 'Expiring soonest'], ['expiry_late', 'Expiring latest'], ['devices', 'Most devices'], ['seen', 'Recently active'], ['az', 'Key A–Z']]
            .map(([v, l]) => `<option value="${v}" ${view.sort === v ? 'selected' : ''}>${l}</option>`).join('')}
        </select>
        <select id="key-per-page" class="mini" aria-label="Rows per page">
          ${[10, 25, 50, 100].map((n) => `<option value="${n}" ${view.perPage === n ? 'selected' : ''}>${n} / page</option>`).join('')}
        </select>
      </div>

      <div class="bulkbar ${view.selected.size ? '' : 'hide'}" id="bulkbar">
        <span><b>${view.selected.size}</b> selected</span>
        <div class="actions">
          <button class="ghost mini" data-bulk="enable">Enable</button>
          <button class="ghost mini" data-bulk="disable">Disable</button>
          <button class="ghost mini" data-bulk="ban">Ban</button>
          <button class="ghost mini" data-bulk="unban">Unban</button>
          <select id="bulk-renew" class="mini" aria-label="Add time">
            <option value="">Add time…</option>
            <option value="7">7 days</option>
            <option value="30">30 days</option>
            <option value="90">90 days</option>
            <option value="365">365 days</option>
          </select>
          <button class="ghost mini" data-bulk="reset">Reset HWID</button>
          <button class="ghost mini" data-bulk="copy">Copy</button>
          <button class="ghost mini danger" data-bulk="delete">Delete</button>
          <button class="ghost mini" data-bulk="clear" aria-label="Clear selection">✕</button>
        </div>
      </div>

      <div class="table-wrap flush">
        <table class="lic-table">
          <thead><tr>
            <th class="chk"><input type="checkbox" id="chk-all" aria-label="Select all" ${slice.length && slice.every((k) => view.selected.has(k.id)) ? 'checked' : ''}></th>
            <th>Key</th><th>Status</th><th>Duration</th><th>HWID</th><th>Created</th><th>Expires</th><th>Note</th><th>Created by</th><th class="right"></th>
          </tr></thead>
          <tbody id="rows" class="anim">
            ${slice.map((k) => rowHtml(k)).join('')}
          </tbody>
        </table>
      </div>
      ${slice.length ? '' : `<div class="empty-state"><b>No licenses found</b><span>Try another search or filter, or create new keys.</span><button class="grad-btn" data-action="create-keys">Create Keys</button></div>`}

      <div class="table-foot">
        <p class="search-help">Filters: ${['status:active', 'tag:vip', 'device:ab12', 'note:shop', 'prefix:SW', 'devices:full', 'lifetime', 'live'].map((f) => `<code>${f}</code>`).join(' ')}</p>
        <div class="pager ${pages > 1 ? '' : 'hide'}">
          <button class="ghost mini" data-page="prev" ${view.page === 1 ? 'disabled' : ''}>← Prev</button>
          <span class="pager-info">Page ${view.page} of ${pages}</span>
          <button class="ghost mini" data-page="next" ${view.page === pages ? 'disabled' : ''}>Next →</button>
        </div>
      </div>
    </div>
  </section>`;
}

function rowHtml(k) {
  const status = statusOf(k);
  const left = daysLeft(k.expiresAt);
  const selected = view.selected.has(k.id);
  return `<tr data-id="${k.id}">
    <td class="chk"><input type="checkbox" data-check="${k.id}" aria-label="Select ${esc(k.key)}" ${selected ? 'checked' : ''}></td>
    <td><span class="key">${esc(k.key)}</span>
      ${k.tags.length ? `<span class="sub">${k.tags.map((t) => `#${esc(t)}`).join(' ')}</span>` : ''}</td>
    <td>${badge(status, status === 'active' ? 'Active' : status === 'lifetime' ? 'Lifetime' : status[0].toUpperCase() + status.slice(1))}</td>
    <td>${esc(durationLabel(k))}</td>
    <td><span class="key">${k.hwid ? esc(k.hwid.slice(0, 13)) : '—'}</span><span class="sub">${k.devices}/${k.maxDevices} devices</span></td>
    <td>${esc(fmtDate(k.createdAt))}</td>
    <td>${status === 'lifetime' ? 'Never' : esc(fmtDate(k.expiresAt))}
      ${status === 'active' && left !== null ? `<span class="sub">${left <= 0 ? 'today' : `${left}d left`}</span>` : ''}</td>
    <td>${esc(k.note || '—')}</td>
    <td>${esc(k.createdBy)}</td>
    <td class="actions-cell"><div class="row-actions">
      <button class="icon-btn" data-act="copy" data-id="${k.id}" title="Copy key">${icon('copy')}</button>
      <button class="icon-btn" data-act="detail" data-id="${k.id}" title="Details">${icon('chevron-right')}</button>
    </div></td>
  </tr>`;
}

function selectedKeys() {
  return state.keys.filter((k) => view.selected.has(k.id));
}

function setStatus(ids, status, action) {
  ids.forEach((id) => {
    const key = state.keys.find((k) => k.id === id);
    if (!key) return;
    key.status = status;
    if (status === 'active' && key.expiresAt && key.expiresAt < Date.now()) {
      key.expiresAt = Date.now() + (key.duration || 2592000000);
    }
    addAudit(action, key.key, 'ok');
  });
  save();
}

function bulk(action) {
  const keys = selectedKeys();
  if (!keys.length && action !== 'clear') return;
  const ids = keys.map((k) => k.id);
  switch (action) {
    case 'enable': setStatus(ids, 'active', 'keys.enable'); toast(`${ids.length} keys enabled`, 'ok'); break;
    case 'disable': setStatus(ids, 'disabled', 'keys.disable'); toast(`${ids.length} keys disabled`, 'ok'); break;
    case 'ban': setStatus(ids, 'banned', 'keys.ban'); toast(`${ids.length} keys banned`, 'ok'); break;
    case 'unban': setStatus(ids, 'active', 'keys.unban'); toast(`${ids.length} keys unbanned`, 'ok'); break;
    case 'reset':
      keys.forEach((k) => { k.hwid = ''; k.devices = 0; addAudit('devices.reset', k.key); });
      save(); toast('HWID reset for selected keys', 'ok'); break;
    case 'copy': copyText(keys.map((k) => k.key).join('\n')); break;
    case 'delete':
      confirmDialog({ title: 'Delete licenses', message: `Delete ${ids.length} selected keys? This cannot be undone.`, confirmLabel: 'Delete', danger: true })
        .then((ok) => {
          if (!ok) return;
          state.keys = state.keys.filter((k) => !view.selected.has(k.id));
          ids.forEach((id) => addAudit('keys.delete', id));
          view.selected.clear(); save(); toast('Keys deleted', 'ok'); document.dispatchEvent(new CustomEvent('sw:refresh'));
        });
      return;
    case 'clear': view.selected.clear(); break;
    default: return;
  }
  document.dispatchEvent(new CustomEvent('sw:refresh'));
}

function exportKeys() {
  const rows = filtered();
  const header = 'key,status,duration_days,devices,max_devices,hwid,created,expires,note,created_by\n';
  const body = rows.map((k) => [
    k.key, statusOf(k), k.duration ? Math.round(k.duration / 86400) : 'lifetime', k.devices, k.maxDevices,
    k.hwid, new Date(k.createdAt).toISOString(), k.expiresAt ? new Date(k.expiresAt).toISOString() : '',
    `"${(k.note || '').replace(/"/g, '""')}"`, k.createdBy
  ].join(',')).join('\n');
  const blob = new Blob([header + body], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `strange-wair-keys-${Date.now()}.csv`; a.click();
  URL.revokeObjectURL(url);
  addAudit('keys.export', `${rows.length} keys`);
  toast(`${rows.length} keys exported`, 'ok');
}

function purgeDialog() {
  openModal({
    title: 'Delete licenses',
    subtitle: 'Cleanup removes keys permanently and is written to the audit log.',
    body: `<div class="inline" style="flex-direction:column;align-items:stretch;gap:8px">
      ${[['expired_unused', 'Delete expired & unused keys'], ['expired', 'Delete expired keys'], ['unused', 'Delete unused keys'], ['banned', 'Delete banned keys']]
        .map(([id, label]) => `<button class="ghost" data-purge="${id}" style="justify-content:flex-start">${icon('trash')}${label}</button>`).join('')}
      <button class="ghost danger" data-purge="all" style="justify-content:flex-start">${icon('alert')}Delete ALL keys…</button>
    </div>`,
    footer: '<button class="ghost" data-close>Cancel</button>',
    onMount(modal, close) {
      modal.querySelectorAll('[data-purge]').forEach((btn) => btn.addEventListener('click', async () => {
        const mode = btn.dataset.purge;
        const before = state.keys.length;
        if (mode === 'all') {
          const ok = await confirmDialog({ title: 'Delete every key', message: `This removes all ${before} licenses. Continue?`, confirmLabel: 'Delete all', danger: true });
          if (!ok) return;
          state.keys = [];
        } else {
          state.keys = state.keys.filter((k) => {
            const status = statusOf(k);
            if (mode === 'expired') return status !== 'expired';
            if (mode === 'banned') return status !== 'banned';
            if (mode === 'unused') return k.devices > 0;
            return !(status === 'expired' && k.devices === 0);
          });
        }
        addAudit('keys.purge', `${before - state.keys.length} keys`);
        save(); close(); toast('Cleanup complete', 'ok');
        document.dispatchEvent(new CustomEvent('sw:refresh'));
      }));
    }
  });
}

export function detailHtml(k) {
  const status = statusOf(k);
  return `
    <div class="pills" style="margin-bottom:14px">${badge(status, status[0].toUpperCase() + status.slice(1))}
      ${k.tags.map((t) => `<span class="badge tag">#${esc(t)}</span>`).join('')}</div>
    <div class="kv">
      <div><div class="k">Duration</div><div class="v">${esc(durationLabel(k))}</div></div>
      <div><div class="k">Devices</div><div class="v">${k.devices} / ${k.maxDevices}</div></div>
      <div><div class="k">Created</div><div class="v">${esc(fmtDate(k.createdAt))}</div></div>
      <div><div class="k">Expires</div><div class="v">${k.expiresAt ? esc(fmtDate(k.expiresAt)) : 'Never'}</div></div>
      <div><div class="k">Created by</div><div class="v">${esc(k.createdBy)}</div></div>
      <div><div class="k">Last seen</div><div class="v">${k.lastSeen ? esc(fmtDateTime(k.lastSeen)) : '—'}</div></div>
    </div>
    <h4>Hardware ID</h4>
    <div class="api-url"><b>${esc(k.hwid || 'not bound')}</b></div>
    <h4>Note</h4>
    <p class="card-sub" style="margin:0">${esc(k.note || 'No note on this key.')}</p>
    <h4>Actions</h4>
    <div class="inline">
      <button class="ghost mini" data-drawer-act="copy">${icon('copy')}Copy key</button>
      <button class="ghost mini" data-drawer-act="reset">${icon('rotate')}Reset HWID</button>
      ${status === 'banned'
        ? '<button class="ghost mini" data-drawer-act="unban">Unban</button>'
        : '<button class="ghost mini danger" data-drawer-act="ban">Ban key</button>'}
      <button class="ghost mini danger" data-drawer-act="delete">${icon('trash')}Delete</button>
    </div>`;
}

export function mount(root, ctx) {
  root.querySelector('#key-tabs')?.addEventListener('click', (event) => {
    const btn = event.target.closest('[data-tab]');
    if (!btn) return;
    view.tab = btn.dataset.tab; view.page = 1; view.selected.clear();
    ctx.refresh();
  });

  const search = root.querySelector('#key-search');
  search?.addEventListener('input', () => {
    view.query = search.value; view.page = 1;
    const caret = search.selectionStart;
    ctx.refresh({ keepFocus: '#key-search', caret });
  });

  root.querySelector('#key-sort')?.addEventListener('change', (event) => {
    view.sort = event.target.value; view.page = 1; ctx.refresh();
  });
  root.querySelector('#key-per-page')?.addEventListener('change', (event) => {
    view.perPage = Number(event.target.value); view.page = 1; ctx.refresh();
  });

  root.querySelector('#chk-all')?.addEventListener('change', (event) => {
    const rows = filtered().slice((view.page - 1) * view.perPage, view.page * view.perPage);
    rows.forEach((k) => (event.target.checked ? view.selected.add(k.id) : view.selected.delete(k.id)));
    ctx.refresh();
  });

  root.querySelectorAll('[data-check]').forEach((box) => box.addEventListener('change', () => {
    box.checked ? view.selected.add(box.dataset.check) : view.selected.delete(box.dataset.check);
    ctx.refresh();
  }));

  root.querySelectorAll('[data-bulk]').forEach((btn) => btn.addEventListener('click', () => bulk(btn.dataset.bulk)));
  root.querySelector('#bulk-renew')?.addEventListener('change', (event) => {
    const days = Number(event.target.value);
    if (!days) return;
    selectedKeys().forEach((k) => {
      const base = Math.max(k.expiresAt || Date.now(), Date.now());
      k.expiresAt = base + days * 86400000;
      if (statusOf(k) !== 'banned') k.status = 'active';
      addAudit('keys.renew', k.key);
    });
    save(); toast(`Added ${days} days to ${view.selected.size} keys`, 'ok');
    ctx.refresh();
  });

  root.querySelectorAll('[data-page]').forEach((btn) => btn.addEventListener('click', () => {
    view.page += btn.dataset.page === 'next' ? 1 : -1;
    ctx.refresh();
  }));

  root.querySelectorAll('[data-act]').forEach((btn) => btn.addEventListener('click', async () => {
    const act = btn.dataset.act;
    if (act === 'copy') {
      const key = state.keys.find((k) => k.id === btn.dataset.id);
      if (key) copyText(key.key);
      return;
    }
    if (act === 'detail') {
      const key = state.keys.find((k) => k.id === btn.dataset.id);
      if (!key) return;
      openDrawer(key.key, detailHtml(key));
      return;
    }
    if (act === 'export') exportKeys();
    if (act === 'import') {
      openModal({
        title: 'Import licenses',
        subtitle: 'Paste one key per line. Existing keys are skipped.',
        body: `<textarea id="import-area" placeholder="SW-XXXX-XXXX-XXXX&#10;SW-YYYY-YYYY-YYYY" aria-label="Keys to import"></textarea>`,
        footer: '<button class="ghost" data-close>Cancel</button><button class="grad-btn" data-import>Import</button>',
        onMount(modal, close) {
          modal.querySelector('[data-import]').addEventListener('click', () => {
            const lines = modal.querySelector('#import-area').value.split(/\n+/).map((l) => l.trim()).filter(Boolean);
            let added = 0;
            lines.forEach((line) => {
              if (state.keys.some((k) => k.key === line)) return;
              state.keys.unshift({
                id: `k_imp_${Date.now()}_${added}`, key: line, status: 'active', duration: 2592000000,
                maxDevices: 1, devices: 0, hwid: '', createdAt: Date.now(),
                expiresAt: Date.now() + 2592000000, note: 'Imported', createdBy: state.admin.user,
                tags: [], lastSeen: null, server: 'EU-West'
              });
              added += 1;
            });
            save(); addAudit('keys.import', `${added} keys`);
            close(); toast(`${added} keys imported`, 'ok');
            document.dispatchEvent(new CustomEvent('sw:refresh'));
          });
        }
      });
    }
    if (act === 'purge') purgeDialog();
  }));

}

export { view as licensesView };

document.addEventListener('sw:drawer-act', (event) => {
  const key = state.keys.find((k) => k.key === event.detail.key);
  if (!key) return;
  const action = event.detail.action;
  if (action === 'copy') copyText(key.key);
  if (action === 'reset') { key.hwid = ''; key.devices = 0; addAudit('devices.reset', key.key); save(); toast('HWID reset', 'ok'); }
  if (action === 'ban') { key.status = 'banned'; addAudit('keys.ban', key.key); save(); toast('Key banned', 'ok'); }
  if (action === 'unban') { key.status = 'active'; addAudit('keys.unban', key.key); save(); toast('Key unbanned', 'ok'); }
  if (action === 'delete') {
    confirmDialog({ title: 'Delete license', message: `Delete ${key.key}?`, confirmLabel: 'Delete', danger: true }).then((ok) => {
      if (!ok) return;
      state.keys = state.keys.filter((k) => k.id !== key.id);
      addAudit('keys.delete', key.key); save(); toast('Key deleted', 'ok');
      document.getElementById('drawer').setAttribute('aria-hidden', 'true');
      document.dispatchEvent(new CustomEvent('sw:refresh'));
    });
    return;
  }
  document.dispatchEvent(new CustomEvent('sw:refresh'));
});
