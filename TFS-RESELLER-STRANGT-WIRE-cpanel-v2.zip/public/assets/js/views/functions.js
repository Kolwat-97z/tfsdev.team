/* Functions: the buyer-console switch list per tier. */
import { state, save, addAudit } from '../store.js';
import { icon, esc, toast, fmtRelative, badge, confirmDialog } from '../ui.js';

const view = { tier: 'basic', query: '', selected: new Set(), log: [] };
const TIERS = [['basic', 'Basic'], ['pro', 'Pro'], ['elite', 'Elite']];

const stateBadge = (value) => badge(value === 'live' ? 'active' : value === 'maintenance' ? 'maint' : 'disabled', value);

function filtered() {
  return state.functions
    .filter((f) => f.tier === view.tier)
    .filter((f) => !view.query || `${f.name} ${f.note}`.toLowerCase().includes(view.query.toLowerCase()));
}

export function render() {
  const rows = filtered();
  return `
  <section class="view" data-view="functions">
    <div class="section table-card">
      <div class="tabs" id="fn-tabs">
        ${TIERS.map(([id, label]) => `<button class="tab ${view.tier === id ? 'on' : ''}" data-tier="${id}">${label}<span>${state.functions.filter((f) => f.tier === id).length}</span></button>`).join('')}
      </div>
      <div class="table-tools">
        <div class="search-inline">${icon('search')}
          <input id="fn-q" value="${esc(view.query)}" placeholder="Search functions in this tier…" aria-label="Search functions">
        </div>
        <span class="count">${rows.length} functions</span>
        <div class="tool-actions"><button class="ghost mini" id="fn-restore">Restore shipped list…</button></div>
      </div>

      <div class="fn-add-row inline">
        <input id="fn-new-name" placeholder="New function name…" aria-label="New function name">
        <select id="fn-new-state" class="mini" aria-label="State">
          <option value="live">Live</option><option value="maintenance">Maintenance</option><option value="hidden">Hidden</option>
        </select>
        <select id="fn-new-tier" class="mini" aria-label="Tier">
          ${TIERS.map(([id, label]) => `<option value="${id}" ${view.tier === id ? 'selected' : ''}>${label}</option>`).join('')}
        </select>
        <input id="fn-new-note" placeholder="Buyer note (optional)" aria-label="Buyer note">
        <button class="grad-btn mini" id="fn-add">Add function</button>
      </div>

      <div class="bulkbar ${view.selected.size ? '' : 'hide'}" id="fn-bulkbar">
        <span><b>${view.selected.size}</b> selected</span>
        <div class="actions">
          <button class="ghost mini" data-fn-bulk="live">Set live</button>
          <button class="ghost mini" data-fn-bulk="maintenance">Set maintenance</button>
          <button class="ghost mini" data-fn-bulk="hidden">Hide from buyers</button>
          <button class="ghost mini danger" data-fn-bulk="delete">Delete</button>
          <button class="ghost mini" data-fn-bulk="clear">✕</button>
        </div>
      </div>

      <div class="table-wrap flush">
        <table class="lic-table">
          <thead><tr><th class="chk"><input type="checkbox" id="fn-chk-all" aria-label="Select all"></th><th>Function</th><th>State</th><th>Tier</th><th>Buyer note</th><th>Updated</th><th class="right"></th></tr></thead>
          <tbody id="fn-rows" class="anim">
            ${rows.map((f) => `<tr data-id="${f.id}">
              <td class="chk"><input type="checkbox" data-fn-check="${f.id}" aria-label="Select ${esc(f.name)}" ${view.selected.has(f.id) ? 'checked' : ''}></td>
              <td><b style="font-weight:600">${esc(f.name)}</b></td>
              <td>${stateBadge(f.state)}</td>
              <td><span class="badge role">${esc(f.tier)}</span></td>
              <td>${esc(f.note || '—')}</td>
              <td>${esc(fmtRelative(f.updated))}</td>
              <td class="actions-cell"><button class="icon-btn danger" data-fn-del="${f.id}" title="Delete">${icon('trash')}</button></td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
      ${rows.length ? '' : `<div class="empty-state"><b>No functions in this tier</b><span>Add one, or restore the list that shipped with the build.</span></div>`}
      <div class="table-foot">
        <p class="search-help"><b style="color:var(--text)">Live</b> appears as an included switch in the buyer console · <b style="color:var(--text)">Maintenance</b> is listed under “Currently unavailable” · <b style="color:var(--text)">Hidden</b> removes it from the console but keeps it here.</p>
      </div>
    </div>

    <div class="section">
      <h2>${icon('activity')}Recent activity</h2>
      <p class="card-sub">Changes made in this session. Buyers see them on their next console load.</p>
      <ul class="activity">
        ${view.log.length ? view.log.map((row) => `<li><span class="a-who">${esc(row.who)}</span><span class="a-txt">${esc(row.text)}</span><time>${esc(fmtRelative(row.at))}</time></li>`).join('')
          : '<li><span class="a-who">—</span><span class="a-txt">No changes yet in this session.</span></li>'}
      </ul>
    </div>
  </section>`;
}

function logChange(text) {
  view.log.unshift({ who: state.admin.user, text, at: Date.now() });
}

export function mount(root, ctx) {
  root.querySelector('#fn-tabs')?.addEventListener('click', (event) => {
    const btn = event.target.closest('[data-tier]');
    if (!btn) return;
    view.tier = btn.dataset.tier;
    view.query = '';
    view.selected.clear();
    ctx.refresh();
  });

  const search = root.querySelector('#fn-q');
  search?.addEventListener('input', () => {
    view.query = search.value;
    const caret = search.selectionStart;
    ctx.refresh({ keepFocus: '#fn-q', caret });
  });

  root.querySelector('#fn-add')?.addEventListener('click', () => {
    const name = root.querySelector('#fn-new-name').value.trim();
    if (!name) { toast('Name the function first', 'err'); return; }
    const entry = {
      id: `f_${Date.now()}`,
      name,
      state: root.querySelector('#fn-new-state').value,
      tier: root.querySelector('#fn-new-tier').value,
      note: root.querySelector('#fn-new-note').value.trim(),
      updated: Date.now()
    };
    state.functions.unshift(entry);
    addAudit('functions.add', name);
    logChange(`Added ${name} to ${entry.tier}`);
    save();
    toast(`${name} added`, 'ok');
    ctx.refresh();
  });

  root.querySelector('#fn-restore')?.addEventListener('click', async () => {
    const ok = await confirmDialog({ title: 'Restore shipped list', message: 'Re-add the functions that shipped with the build? Existing entries are kept.', confirmLabel: 'Restore' });
    if (!ok) return;
    const shipped = [['Aimbot', 'elite'], ['ESP Box', 'basic'], ['Bunnyhop', 'basic'], ['Anti AFK', 'basic'], ['Skeleton ESP', 'pro']];
    shipped.forEach(([name, tier]) => {
      if (!state.functions.some((f) => f.name === name && f.tier === tier)) {
        state.functions.push({ id: `f_r_${Date.now()}_${name}`, name, state: 'live', tier, note: '', updated: Date.now() });
      }
    });
    save(); toast('Shipped list restored', 'ok'); ctx.refresh();
  });

  root.querySelector('#fn-chk-all')?.addEventListener('change', (event) => {
    filtered().forEach((f) => (event.target.checked ? view.selected.add(f.id) : view.selected.delete(f.id)));
    ctx.refresh();
  });

  root.querySelectorAll('[data-fn-check]').forEach((box) => box.addEventListener('change', () => {
    box.checked ? view.selected.add(box.dataset.fnCheck) : view.selected.delete(box.dataset.fnCheck);
    ctx.refresh();
  }));

  root.querySelectorAll('[data-fn-bulk]').forEach((btn) => btn.addEventListener('click', async () => {
    const action = btn.dataset.fnBulk;
    if (action === 'clear') { view.selected.clear(); ctx.refresh(); return; }
    if (!view.selected.size) return;
    if (action === 'delete') {
      const ok = await confirmDialog({ title: 'Delete functions', message: `Remove ${view.selected.size} functions from the console?`, confirmLabel: 'Delete', danger: true });
      if (!ok) return;
      state.functions = state.functions.filter((f) => !view.selected.has(f.id));
      logChange(`Deleted ${view.selected.size} functions`);
      toast('Functions deleted', 'ok');
    } else {
      state.functions.forEach((f) => { if (view.selected.has(f.id)) f.state = action; });
      logChange(`Set ${view.selected.size} functions to ${action}`);
      toast(`State set to ${action}`, 'ok');
    }
    addAudit('functions.bulk', `${action} · ${view.selected.size}`);
    view.selected.clear();
    save();
    ctx.refresh();
  }));

  root.querySelectorAll('[data-fn-del]').forEach((btn) => btn.addEventListener('click', async () => {
    const fn = state.functions.find((f) => f.id === btn.dataset.fnDel);
    if (!fn) return;
    const ok = await confirmDialog({ title: 'Delete function', message: `Remove ${fn.name} from the buyer console?`, confirmLabel: 'Delete', danger: true });
    if (!ok) return;
    state.functions = state.functions.filter((f) => f.id !== fn.id);
    addAudit('functions.delete', fn.name);
    logChange(`Deleted ${fn.name}`);
    save(); toast('Function deleted', 'ok'); ctx.refresh();
  }));
}
