/* Role-aware dashboard: Owner sees system-wide analytics; ตัวแทนs see only their own account. */
import { state, statusOf, statusCounts } from '../store.js';
import {
  icon, esc, fmtNum, fmtRelative, fmtDate, daysLeft, badge, sparkline, areaChart,
  donutChart, emptyRow
} from '../ui.js';

const COLORS = { active: '#15803d', pending: '#0e7490', expired: '#b45309', disabled: '#c81e1e', banned: '#7f1d1d', lifetime: '#0e7490' };
const range = { days: 14 };

function seriesFor(keys, days) {
  const buckets = Array.from({ length: days }, () => 0);
  const start = new Date(); start.setHours(0, 0, 0, 0);
  const startTime = start.getTime() - (days - 1) * 86400000;
  keys.forEach((k) => {
    if (k.createdAt < startTime) return;
    const index = Math.floor((k.createdAt - startTime) / 86400000);
    if (index >= 0 && index < days) buckets[index] += 1;
  });
  const labels = buckets.map((_, i) => new Date(startTime + i * 86400000).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }));
  return { buckets, labels };
}

function scope() {
  const owner = state.admin.role === 'owner';
  const keys = owner ? state.keys : state.keys.filter((k) => state.sellerOwnership?.[k.key] === state.admin.user);
  const devices = owner ? state.devices : state.devices.filter((d) => keys.some((k) => k.key === d.key));
  return { owner, keys, devices };
}

function expiringSoon(keys) {
  return keys.filter((k) => statusOf(k) === 'active' && k.expiresAt && daysLeft(k.expiresAt) <= 7 && daysLeft(k.expiresAt) >= 0)
    .sort((a, b) => a.expiresAt - b.expiresAt).slice(0, 5);
}

function ownerLeaderboard(keys) {
  const map = new Map();
  keys.forEach((k) => {
    const who = k.createdBy || 'unknown';
    const row = map.get(who) || { user: who, total: 0, active: 0 };
    row.total += 1;
    if (statusOf(k) === 'active' || statusOf(k) === 'lifetime') row.active += 1;
    map.set(who, row);
  });
  return [...map.values()].sort((a, b) => b.total - a.total).slice(0, 5);
}

function ownerCreditOverview() {
  const transactions = (state.creditTransactions || []).slice().sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  const resellerUsers = state.admins.filter((u) => u.role === 'reseller' || u.role === 'reseller_vip');
  const totalUsed = transactions.reduce((sum, tx) => sum + Number(tx.amount || 0), 0);
  const byUser = new Map(resellerUsers.map((u) => [u.user, { user: u.user, name: u.name, total: 0, count: 0 }]));
  transactions.forEach((tx) => {
    const row = byUser.get(tx.user) || { user: tx.user, name: tx.user, total: 0, count: 0 };
    row.total += Number(tx.amount || 0);
    row.count += 1;
    byUser.set(tx.user, row);
  });
  const leaders = [...byUser.values()].sort((a, b) => b.total - a.total).slice(0, 5);
  return `<div class="section credit-overview"><div class="card-head"><div><h3>ภาพรวมการใช้เครดิตของตัวแทน</h3><p>รวมรายการหักเครดิตจากการสร้างคีย์ทั้งหมด</p></div><button class="ghost mini" data-action="goto" data-view="credit-history">ดูประวัติเครดิต</button></div>
    <div class="credit-summary-grid"><div><span>เครดิตที่ใช้ทั้งหมด</span><b>${fmtNum(totalUsed)}</b><small>เครดิต</small></div><div><span>รายการทั้งหมด</span><b>${fmtNum(transactions.length)}</b><small>รายการ</small></div><div><span>ตัวแทนที่มีรายการ</span><b>${fmtNum(new Set(transactions.map((tx) => tx.user)).size)}</b><small>บัญชี</small></div></div>
    <div class="credit-overview-grid"><div><h4>ตัวแทนที่ใช้เครดิตสูงสุด</h4><div class="credit-rank-list">${leaders.length ? leaders.map((r, i) => `<div class="credit-rank"><span class="rank">${i + 1}</span><div><b>${esc(r.name || r.user)}</b><small>${esc(r.user)} · ${fmtNum(r.count)} รายการ</small></div><strong>${fmtNum(r.total)} เครดิต</strong></div>`).join('') : '<p class="muted">ยังไม่มีรายการหักเครดิต</p>'}</div></div><div><h4>รายการล่าสุด</h4><div class="credit-latest-list">${transactions.slice(0, 5).map((tx) => `<div class="credit-latest"><div><b>${esc(tx.user)}</b><small>${esc(tx.durationLabel || 'สร้างคีย์')} · ${fmtNum(tx.quantity || 0)} คีย์</small></div><strong>-${fmtNum(tx.amount || 0)}</strong><time>${esc(fmtRelative(tx.createdAt))}</time></div>`).join('') || '<p class="muted">ยังไม่มีรายการหักเครดิต</p>'}</div></div></div>
  </div>`;
}

function kpiCard(kpi) {
  return `<div class="stat kpi"><div class="kpi-top"><span>${esc(kpi.label)}</span><span class="trend ${kpi.down || kpi.delta < 0 ? 'down' : ''}">${icon('trend-up')}${kpi.delta > 0 ? '+' : ''}${kpi.delta}%</span></div><b>${fmtNum(kpi.value)}</b><div class="kpi-foot">${esc(kpi.note)}</div>${sparkline(kpi.spark, 150, 46)}</div>`;
}

function commonSections(keys, devices, counts, soon, buckets, labels, currentTotal, legend, owner) {
  return `
    <div class="dash-grid">
      <div class="section chart-card"><div class="card-head"><div><h3>Licenses created</h3><p>Last ${range.days} days · ${currentTotal} คีย์</p></div><div class="seg" id="chart-range">${[7,14,30].map((d) => `<button data-days="${d}" class="${d === range.days ? 'on' : ''}">${d}d</button>`).join('')}</div></div><div class="chart" id="dash-chart">${areaChart(buckets, labels)}</div></div>
      <div class="section"><div class="card-head"><div><h3>Status breakdown</h3><p>${owner ? 'คีย์ทั้งหมดแยกตามสถานะ' : 'คีย์ของคุณแยกตามสถานะ'}</p></div></div><div class="donut-wrap">${donutChart(legend, counts.all)}<ul class="legend">${legend.map((s) => `<li><span class="sw" style="background:${s.color}"></span>${esc(s.label)}<b>${fmtNum(s.value)}</b></li>`).join('')}</ul></div></div>
    </div>
    <div class="dash-grid three">
      <div class="section list-card"><div class="card-head"><div><h3>Expiring soon</h3><p>${owner ? 'คีย์ที่ใช้งานและใกล้หมดอายุใน 7 วัน' : 'Your คีย์ ending in the next 7 days'}</p></div><button class="ghost mini" data-action="goto" data-view="licenses">ดูทั้งหมด</button></div><ul class="rows-list">${soon.length ? soon.map((k) => `<li><button class="mk-key" data-action="open-key" data-id="${k.id}">${esc(k.key)}</button>${badge('expired', `${daysLeft(k.expiresAt)}d left`)}</li>`).join('') : emptyRow('ไม่มีคีย์หมดอายุภายในสัปดาห์นี้')}</ul></div>
      <div class="section list-card"><div class="card-head"><div><h3>${owner ? 'กิจกรรมล่าสุด' : 'กิจกรรมของฉัน'}</h3><p>${owner ? 'Latest owner actions' : 'Latest actions on your account'}</p></div><button class="ghost mini" data-action="goto" data-view="logs">ดูทั้งหมด</button></div><ul class="timeline">${state.audit.filter((r) => owner || r.actor === state.admin.user || keys.some((k) => k.key === r.target)).slice(0,5).map((row) => `<li class="${row.result === 'denied' ? 'bad' : 'ok'}"><span class="t-ic">${icon(row.result === 'denied' ? 'ban' : 'check')}</span><div><b>${esc(row.action)}</b><span>${esc(row.actor)} · ${esc(row.target)}</span></div><small>${esc(fmtRelative(row.at))}</small></li>`).join('')}</ul></div>
      <div class="section list-card"><div class="card-head"><div><h3>Newest คีย์</h3><p>${owner ? 'สร้างล่าสุด' : 'คีย์ของคุณที่สร้างล่าสุด'}</p></div><button class="ghost mini" data-action="goto" data-view="licenses">ดูทั้งหมด</button></div><ul class="rows-list">${keys.slice().sort((a,b) => b.createdAt-a.createdAt).slice(0,4).map((k) => `<li><button class="mk-key" data-action="open-key" data-id="${k.id}">${esc(k.key)}</button><small>${esc(fmtDate(k.createdAt))}</small></li>`).join('')}</ul></div>
      ${owner ? `<div class="section health-strip"><div class="card-head"><div><h3>สุขภาพระบบ</h3><p>พื้นที่จัดเก็บ ฐานข้อมูล และบันทึกกิจกรรม</p></div><button class="ghost mini" data-action="goto" data-view="health">รายละเอียด</button></div><div class="pills">${state.health.map((h) => `<span class="pill ${h.tone}"><span class="dot"></span>${esc(h.label)} · ${esc(h.value)}</span>`).join('')}</div></div>` : `<div class="section health-strip"><div class="card-head"><div><h3>สถานะบัญชี</h3><p>บัญชีตัวแทนของคุณ</p></div><button class="ghost mini" data-action="goto" data-view="security">Profile</button></div><div class="account-summary"><span class="pill ok"><span class="dot"></span>บัญชีใช้งานอยู่</span><span class="role-chip">${esc(state.admin.role)}</span><span class="muted">${state.admin.role === 'reseller_vip' ? 'Unlimited generation' : `${fmtNum(state.admin.credits ?? 0)} credits remaining`}</span></div></div>`}
    </div>`;
}

export function render() {
  const { owner, keys, devices } = scope();
  const counts = statusCounts(keys); const active = counts.active + counts.lifetime;
  const { buckets, labels } = seriesFor(keys, range.days); const prev = seriesFor(keys, range.days * 2).buckets.slice(0, range.days);
  const currentTotal = buckets.reduce((a,b) => a+b, 0); const prevTotal = prev.reduce((a,b) => a+b, 0);
  const growth = prevTotal ? Math.round(((currentTotal - prevTotal) / prevTotal) * 100) : 0; const soon = expiringSoon(keys);
  const legend = [{label:'ใช้งานอยู่',value:counts.active,color:COLORS.active},{label:'ยังไม่เริ่มใช้',value:counts.pending,color:COLORS.pending},{label:'หมดอายุ',value:counts.expired,color:COLORS.expired},{label:'ปิดใช้งาน',value:counts.disabled,color:COLORS.disabled},{label:'ถูกระงับ',value:counts.banned,color:COLORS.banned},{label:'ถาวร',value:counts.lifetime,color:COLORS.lifetime}].filter((s) => s.value > 0);
  const today = new Date().toLocaleDateString('en-GB', { weekday:'long', day:'numeric', month:'long', year:'numeric' });
  const kpis = owner ? [
    {label:'คีย์ทั้งหมด',value:counts.all,delta:growth,note:`${currentTotal} in last ${range.days} days`,ic:'key',spark:buckets},
    {label:'ตัวแทนทั้งหมด',value:state.admins.filter((u) => u.role === 'reseller' || u.role === 'reseller_vip').length,delta:4,note:'Active reseller accounts',spark:buckets.map((v)=>v+2)},
    {label:'คีย์ที่ใช้งาน',value:active,delta:6,note:`${counts.lifetime} lifetime`,spark:buckets.map((v)=>v+3)},
    {label:'อุปกรณ์ที่ผูก',value:devices.length,delta:12,note:'รวมทุกตัวแทน',spark:buckets.map((v)=>v*2+1)}
  ] : [
    {label:'คีย์ของฉัน',value:counts.all,delta:growth,note:`${currentTotal} created in last ${range.days} days`,spark:buckets},
    {label:'คีย์ที่ใช้งาน',value:active,delta:6,note:`${counts.lifetime} lifetime`,spark:buckets.map((v)=>v+1)},
    {label:'อุปกรณ์ที่ผูก',value:devices.length,delta:12,note:'อุปกรณ์ที่ใช้คีย์ของคุณ',spark:buckets.map((v)=>v*2+1)},
    {label:'เครดิตคงเหลือ',value:state.admin.role === 'reseller_vip' ? '∞' : (state.admin.credits ?? 0),delta:0,note:state.admin.role === 'reseller_vip' ? 'VIP ไม่จำกัด' : 'หักตามจำนวนคีย์',spark:buckets.map((v)=>v+1)}
  ];
  const leaderboard = ownerLeaderboard(state.keys);
  return `<section class="view" data-view="dashboard"><div class="hero"><div><p class="hero-kicker">${esc(today)} · <span class="role-chip">${owner ? 'ภาพรวม Owner' : (state.admin.role === 'reseller_vip' ? 'ตัวแทน VIP' : 'ตัวแทน')}</span></p><h2 class="hero-title">ยินดีต้อนรับ, ${esc(state.admin.name)}</h2><p class="hero-sub">${owner ? `${fmtNum(counts.active)} คีย์กำลังใช้งานจาก ${fmtNum(state.admins.filter((u) => u.role === 'reseller' || u.role === 'reseller_vip').length)} บัญชีตัวแทน` : `${fmtNum(counts.active)} จากคีย์ของคุณกำลังใช้งาน และ ${fmtNum(soon.length)} รายการต้องตรวจสอบภายในสัปดาห์นี้`}</p></div><div class="tool-actions"><button class="ghost" data-action="goto" data-view="logs">${icon('activity')}กิจกรรม</button><button class="grad-btn" data-action="create-keys">${icon('plus-circle')}สร้างคีย์</button></div></div><div class="kpis">${kpis.map(kpiCard).join('')}</div>${owner ? `<div class="section leaderboard"><div class="card-head"><div><h3>ตัวแทนที่สร้างคีย์มากที่สุด</h3><p>อันดับ 1–5 ตามจำนวนคีย์ที่สร้าง</p></div><button class="ghost mini" data-action="goto" data-view="users">จัดการตัวแทน</button></div><div class="leaderboard-grid">${leaderboard.map((r,i) => `<div class="leader-row"><span class="rank">${i+1}</span><span class="avatar mini-avatar">${esc(r.user.slice(0,2).toUpperCase())}</span><div class="leader-who"><b>${esc(r.user)}</b><small>${fmtNum(r.active)} คีย์ใช้งาน</small></div><strong>${fmtNum(r.total)}</strong><span class="muted">คีย์</span></div>`).join('')}</div></div>${ownerCreditOverview()}` : ''}${commonSections(keys, devices, counts, soon, buckets, labels, currentTotal, legend, owner)}</section>`;
}

export function mount(root, ctx) {
  root.querySelectorAll('#chart-range button').forEach((btn) => btn.addEventListener('click', () => { range.days = Number(btn.dataset.days); ctx.refresh(); }));
  root.querySelectorAll('[data-action="open-key"]').forEach((btn) => btn.addEventListener('click', () => ctx.openKey(btn.dataset.id)));
}
