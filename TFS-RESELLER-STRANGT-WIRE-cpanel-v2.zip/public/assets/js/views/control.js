/* Control Panel: per-tier feature switches with a live update dialog. */
import { state, save, addAudit } from '../store.js';
import { icon, esc, toast, openModal, fmtRelative } from '../ui.js';

const view = { tier: 'basic', query: '', log: [] };

const TIERS = [['basic', 'Basic'], ['pro', 'Pro'], ['elite', 'Elite']];

function tierOnline(tier) {
  return state.features[tier].some(([, , on]) => on);
}

export function render() {
  const features = state.features[view.tier];
  const filtered = features
    .map(([name, group, on], index) => ({ name, group, on, index }))
    .filter((f) => !view.query || `${f.name} ${f.group}`.toLowerCase().includes(view.query.toLowerCase()));
  const onlineCount = features.filter(([, , on]) => on).length;

  return `
  <section class="view" data-view="control">
    <div class="section table-card">
      <div class="tabs" id="cp-tabs">
        ${TIERS.map(([id, label]) => `<button class="tab ${view.tier === id ? 'on' : ''}" data-tier="${id}">
          <span class="tabdot ${tierOnline(id) ? 'on' : 'off'}"></span>${label}
        </button>`).join('')}
      </div>
      <div class="table-tools">
        <div class="search-inline">${icon('search')}
          <input id="cp-q" value="${esc(view.query)}" placeholder="Search features in this tier…" aria-label="Search features">
        </div>
        <span class="count">${filtered.length} features · ${onlineCount} live</span>
        <div class="tool-actions">
          <span class="badge ${tierOnline(view.tier) ? 'active' : 'disabled'}">${tierOnline(view.tier) ? 'online' : 'offline'}</span>
          <button class="ghost mini" id="cp-refresh">${icon('refresh')}Refresh</button>
          <button class="ghost mini danger" id="cp-alloff">Turn all off</button>
        </div>
      </div>
      <div class="table-wrap flush">
        <table class="lic-table">
          <thead><tr><th>Feature</th><th>Group</th><th class="cp-set-h">Setting</th></tr></thead>
          <tbody id="cp-rows" class="anim">
            ${filtered.map((f) => `<tr>
              <td><b style="font-weight:600">${esc(f.name)}</b></td>
              <td><span class="cp-grp">${esc(f.group)}</span></td>
              <td class="cp-set-td"><label class="switch"><input type="checkbox" data-feature="${f.index}" ${f.on ? 'checked' : ''} aria-label="${esc(f.name)}"><i></i></label></td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
      ${filtered.length ? '' : `<div class="empty-state"><b>No features match</b><span>Clear the search to see every switch in this tier.</span></div>`}
    </div>

    <div class="section">
      <h2>${icon('activity')}Recent activity</h2>
      <p class="card-sub">Changes you make in this session, applied to every key in the tier.</p>
      <ul class="activity">
        ${view.log.length ? view.log.map((row) => `<li><span class="a-who">${esc(row.who)}</span><span class="a-txt">${esc(row.text)}</span><time>${esc(fmtRelative(row.at))}</time></li>`).join('')
          : '<li><span class="a-who">—</span><span class="a-txt">No changes yet in this session.</span></li>'}
      </ul>
    </div>
  </section>`;
}

function runPipeline(featureName, target, onDone) {
  const keys = state.keys.slice(0, 12).map((k) => k.key);
  const total = keys.length;
  const body = `
    <div class="cp-load-body">
      <div class="cp-progress-summary">
        <div class="cp-summary-col"><span class="cp-sum-lbl">Feature</span><b class="cp-sum-val">${esc(featureName)}</b></div>
        <div class="cp-summary-col"><span class="cp-sum-lbl">Target action</span><b class="cp-sum-val">Turning ${target ? 'ON' : 'OFF'}</b></div>
        <div class="cp-summary-col right"><span class="cp-sum-lbl">Progress</span><b class="cp-sum-val" data-pct>0%</b></div>
      </div>
      <div class="cp-progress-track"><div class="cp-progress-fill" data-bar></div></div>
      <div class="cp-progress-counts"><span data-step>Connecting to key pipeline…</span><span data-count>0 / ${total} keys</span></div>
      <div class="cp-stream-box">
        <div class="cp-stream-head"><span>Key update pipeline (live 1-by-1)</span><span class="cp-live-indicator">LIVE STREAM</span></div>
        <ul class="cp-stream-list" data-stream></ul>
      </div>
    </div>`;

  const { modal, close } = openModal({
    title: '',
    body,
    wide: true,
    onMount(node) {
      const head = node.querySelector('.dlg-head');
      if (head) head.style.display = 'none';
      const foot = node.querySelector('.modal-foot');
      if (foot) foot.remove();
    }
  });

  const bar = modal.querySelector('[data-bar]');
  const pct = modal.querySelector('[data-pct]');
  const step = modal.querySelector('[data-step]');
  const count = modal.querySelector('[data-count]');
  const stream = modal.querySelector('[data-stream]');

  let index = 0;
  const tick = () => {
    if (index >= total) {
      step.textContent = 'Done — all keys synced.';
      setTimeout(() => { close(); onDone(); }, 550);
      return;
    }
    const key = keys[index];
    const li = document.createElement('li');
    li.className = 'cp-stream-item';
    li.innerHTML = `<span><span class="cp-stream-idx">#${String(index + 1).padStart(2, '0')}</span>${esc(key)}</span><span class="ok">✓ synced</span>`;
    stream.prepend(li);
    index += 1;
    const percent = Math.round((index / total) * 100);
    bar.style.width = `${percent}%`;
    pct.textContent = `${percent}%`;
    count.textContent = `${index} / ${total} keys`;
    step.textContent = `Pushing ${featureName} to ${key}…`;
    setTimeout(tick, 130);
  };
  setTimeout(tick, 250);
}

export function mount(root, ctx) {
  root.querySelector('#cp-tabs')?.addEventListener('click', (event) => {
    const btn = event.target.closest('[data-tier]');
    if (!btn) return;
    view.tier = btn.dataset.tier;
    view.query = '';
    ctx.refresh();
  });

  const search = root.querySelector('#cp-q');
  search?.addEventListener('input', () => {
    view.query = search.value;
    const caret = search.selectionStart;
    ctx.refresh({ keepFocus: '#cp-q', caret });
  });

  root.querySelector('#cp-refresh')?.addEventListener('click', () => {
    toast('Feature state refreshed', 'ok');
    ctx.refresh();
  });

  root.querySelector('#cp-alloff')?.addEventListener('click', () => {
    state.features[view.tier] = state.features[view.tier].map(([name, group]) => [name, group, false]);
    addAudit('control.alloff', view.tier);
    view.log.unshift({ who: state.admin.user, text: `Turned off every feature in ${view.tier}`, at: Date.now() });
    save();
    toast(`All ${view.tier} features turned off`, 'ok');
    ctx.refresh();
  });

  root.querySelectorAll('[data-feature]').forEach((input) => input.addEventListener('change', () => {
    const index = Number(input.dataset.feature);
    const [name, group] = state.features[view.tier][index];
    const on = input.checked;
    input.disabled = true;
    runPipeline(name, on, () => {
      state.features[view.tier][index] = [name, group, on];
      view.log.unshift({ who: state.admin.user, text: `${on ? 'Enabled' : 'Disabled'} ${name} for ${view.tier}`, at: Date.now() });
      addAudit('control.toggle', `${name} · ${view.tier}`);
      save();
      toast(`${name} ${on ? 'enabled' : 'disabled'}`, 'ok');
      ctx.refresh();
    });
  }));
}
