/* Contact directory: public contact links; owner edits them in Settings. */
import { state } from '../store.js';
import { icon, esc } from '../ui.js';

const linkOrDash = (value) => value ? `<a class="contact-link" href="${esc(value)}" target="_blank" rel="noopener noreferrer">${esc(value)}</a>` : '<span class="muted">ยังไม่ได้ตั้งค่า</span>';

export function render() {
  const c = state.settings.contact || {};
  return `<section class="view contact-view" data-view="contact">
    <div class="hero"><div><p class="hero-kicker">CONTACT</p><h2 class="hero-title">ช่องทางติดต่อทีมงาน</h2><p class="hero-sub">ใช้ Discord หรือ Telegram สำหรับการช่วยเหลือและประกาศระบบ</p></div></div>
    <div class="contact-grid">
      <article class="section contact-card"><div class="contact-icon discord">${icon('users')}</div><div><h2>Discord</h2><p class="card-sub">ชุมชนและห้องสนับสนุนแบบเรียลไทม์</p><div class="contact-value">${linkOrDash(c.discordUrl)}</div></div>${c.discordUrl ? `<a class="grad-btn" href="${esc(c.discordUrl)}" target="_blank" rel="noopener noreferrer">เปิด Discord ${icon('external')}</a>` : ''}</article>
      <article class="section contact-card"><div class="contact-icon telegram">${icon('send')}</div><div><h2>Telegram</h2><p class="card-sub">ติดต่อทีมงานและรับข่าวสารการให้บริการ</p><div class="contact-value">${linkOrDash(c.telegramUrl)}</div></div>${c.telegramUrl ? `<a class="grad-btn" href="${esc(c.telegramUrl)}" target="_blank" rel="noopener noreferrer">เปิด Telegram ${icon('external')}</a>` : ''}</article>
    </div>
    <div class="section contact-note"><h2>${icon('shield')}การใช้งานอย่างปลอดภัย</h2><p class="card-sub">อย่าส่งรหัสผ่าน, API key หรือ webhook secret ในห้องสนทนา ทีมงานจะไม่ขอข้อมูลลับเหล่านี้</p></div>
  </section>`;
}
