/* Devices: scoped to the signed-in reseller, with one-click HWID reset. */
import { state, save, addAudit } from '../store.js';
import { icon, esc, fmtDateTime, fmtRelative, fmtNum, confirmDialog, toast } from '../ui.js';
import { sellerAction } from '../seller-api.js';

const view = { page: 1, perPage: 10, query: '' };

function rows() {
  const q = view.query.trim().toLowerCase();
  const owner = state.admin.role === 'owner';
  const ownedKeys = owner ? state.keys : state.keys.filter((k) => state.sellerOwnership?.[k.key] === state.admin.user);
  const owned = new Set(ownedKeys.map((k) => k.key));
  return state.devices
    .filter((d) => owner || owned.has(d.key))
    .filter((d) => !q || [d.hwid, d.key, d.server, d.profile].join(' ').toLowerCase().includes(q))
    .sort((a, b) => b.lastSeen - a.lastSeen);
}

async function resetHardware(device, ctx) {
  const ok = await confirmDialog({
    title: 'รีเซ็ต HWID',
    message: `Unbind ${device.hwid} from ${device.key}? The next device can activate this key.`,
    confirmLabel: 'รีเซ็ต HWID',
    danger: true
  });
  if (!ok) return;
  try {
    await sellerAction('reset', { key: device.key, device_id: device.hwid || undefined });
    addAudit('devices.reset_hwid', device.key);
    save();
    toast('รีเซ็ต HWID สำเร็จ — คีย์พร้อมใช้กับอุปกรณ์ใหม่', 'ok');
    ctx.refresh();
  } catch (error) {
    toast(`รีเซ็ตไม่สำเร็จ: ${error.message}`, 'err');
  }
}

export function render() {
  const list = rows();
  const pages = Math.max(1, Math.ceil(list.length / view.perPage));
  view.page = Math.min(view.page, pages);
  const slice = list.slice((view.page - 1) * view.perPage, view.page * view.perPage);
  const owner = state.admin.role === 'owner';

  return `
  <section class="view" data-view="devices">
    <div class="section">
      <div class="toolbar">
        <div><h2>${icon('monitor')}${owner ? 'อุปกรณ์ทั้งหมด' : 'อุปกรณ์ของฉัน'}</h2><p class="card-sub" style="margin:0">${owner ? 'All hardware IDs bound across reseller accounts.' : 'Reset a hardware ID yourself when a customer changes computer.'}</p></div>
        <span class="count">${fmtNum(list.length)} devices</span>
      </div>
      <div class="device-help"><span class="pill warn"><span class="dot"></span>Reset is immediate</span><span class="muted">The old device loses access and the key can bind again on next launch.</span></div>
      <div class="table-tools" style="padding:0 0 12px"><div class="search-inline">${icon('search')}<input id="device-search" value="${esc(view.query)}" placeholder="Search HWID, key or server…" aria-label="Search devices"></div></div>
      <div class="table-wrap"><table><thead><tr><th>Hardware ID</th><th>Key</th><th>Server</th><th>Bound</th><th>Last seen</th><th>Profile</th><th class="right">Actions</th></tr></thead>
        <tbody id="device-rows" class="anim">${slice.map((d) => `<tr><td><span class="key">${esc(d.hwid)}</span></td><td><span class="key">${esc(d.key)}</span></td><td>${esc(d.server)}</td><td>${esc(fmtDateTime(d.bound))}</td><td>${esc(fmtRelative(d.lastSeen))}</td><td><span class="badge on">active</span> <span class="sub" style="display:inline">${esc(d.profile)}</span></td><td class="actions-cell"><button class="ghost mini danger" data-reset-hwid="${d.id}">${icon('rotate')}Reset HWID</button></td></tr>`).join('')}</tbody>
      </table></div>
      ${slice.length ? '' : '<p class="empty">No bound devices in your scope.</p>'}
      <div class="pager ${pages > 1 ? '' : 'hide'}"><button class="ghost mini" data-page="prev" ${view.page === 1 ? 'disabled' : ''}>← Prev</button><span class="pager-info">Page ${view.page} of ${pages}</span><button class="ghost mini" data-page="next" ${view.page === pages ? 'disabled' : ''}>Next →</button></div>
    </div>
  </section>`;
}

export function mount(root, ctx) {
  const search = root.querySelector('#device-search');
  search?.addEventListener('input', () => { view.query = search.value; view.page = 1; const caret = search.selectionStart; ctx.refresh({ keepFocus: '#device-search', caret }); });
  root.querySelectorAll('[data-page]').forEach((btn) => btn.addEventListener('click', () => { view.page += btn.dataset.page === 'next' ? 1 : -1; ctx.refresh(); }));
  root.querySelectorAll('[data-reset-hwid]').forEach((btn) => btn.addEventListener('click', () => { const device = state.devices.find((d) => d.id === btn.dataset.resetHwid); if (device) resetHardware(device, ctx); }));
}
