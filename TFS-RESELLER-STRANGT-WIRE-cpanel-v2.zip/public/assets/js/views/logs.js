/* Activity log: filterable, tamper-evident audit trail. */
import { state, addAudit, save } from '../store.js';
import { icon, esc, fmtDateTime, badge, toast, fmtNum } from '../ui.js';

const view = { action: '', actor: '', target: '', page: 1, perPage: 12, verified: false };

function rows() {
  const a = view.action.trim().toLowerCase();
  const u = view.actor.trim().toLowerCase();
  const t = view.target.trim().toLowerCase();
  return state.audit
    .filter((r) => (!a || r.action.toLowerCase().includes(a)))
    .filter((r) => (!u || r.actor.toLowerCase().includes(u)))
    .filter((r) => (!t || String(r.target).toLowerCase().includes(t)));
}

export function render() {
  const list = rows();
  const pages = Math.max(1, Math.ceil(list.length / view.perPage));
  view.page = Math.min(view.page, pages);
  const slice = list.slice((view.page - 1) * view.perPage, view.page * view.perPage);

  return `
  <section class="view" data-view="logs">
    <div class="section">
      <div class="toolbar">
        <h2>${icon('activity')}Activity Log</h2>
        <div class="tool-actions">
          <span class="count">${fmtNum(list.length)} entries</span>
          <button class="ghost mini" id="audit-verify">Verify integrity</button>
          <button class="ghost mini danger" id="audit-purge">Purge…</button>
        </div>
      </div>

      <div class="filter-bar">
        <input id="audit-action" value="${esc(view.action)}" placeholder="Filter by action (e.g. keys.create)" aria-label="Filter by action">
        <input id="audit-actor" value="${esc(view.actor)}" placeholder="Filter by actor" aria-label="Filter by actor">
        <input id="audit-target" value="${esc(view.target)}" placeholder="Filter by key / target" aria-label="Filter by target">
        <button class="ghost mini" id="audit-refresh">Apply</button>
      </div>

      <p class="chain-note">${icon('shield')}
        ${view.verified
          ? `Chain verified · ${fmtNum(state.audit.length)} entries · hash of the newest entry matches the stored head.`
          : `Chain head ${esc(`0x${(state.audit[0]?.id || 'genesis').replace(/\W/g, '').slice(0, 12)}`)} · every entry links to the previous hash.`}
      </p>

      <div class="table-wrap">
        <table>
          <thead><tr><th>Time</th><th>Actor</th><th>Role</th><th>Action</th><th>Target</th><th>Result</th><th>IP</th></tr></thead>
          <tbody id="audit-rows" class="anim">
            ${slice.map((r) => `<tr>
              <td>${esc(fmtDateTime(r.at))}</td>
              <td><b style="font-weight:600">${esc(r.actor)}</b></td>
              <td><span class="badge role">${esc(r.role)}</span></td>
              <td><span class="key">${esc(r.action)}</span></td>
              <td><span class="key" style="color:var(--muted)">${esc(String(r.target).slice(0, 24))}</span></td>
              <td>${badge(r.result === 'ok' ? 'active' : 'banned', r.result === 'ok' ? 'ok' : 'denied')}</td>
              <td><span class="key" style="color:var(--dim)">${esc(r.ip)}</span></td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
      ${slice.length ? '' : '<p class="empty">No entries match these filters.</p>'}

      <div class="pager">
        <button class="ghost mini" id="audit-prev" ${view.page === 1 ? 'disabled' : ''}>← Prev</button>
        <span class="pager-info">Page ${view.page} of ${pages}</span>
        <button class="ghost mini" id="audit-next" ${view.page === pages ? 'disabled' : ''}>Next →</button>
      </div>
    </div>
  </section>`;
}

export function mount(root, ctx) {
  const bind = (id, field) => {
    const input = root.querySelector(id);
    input?.addEventListener('input', () => {
      view[field] = input.value;
      view.page = 1;
      const caret = input.selectionStart;
      ctx.refresh({ keepFocus: id, caret });
    });
  };
  bind('#audit-action', 'action');
  bind('#audit-actor', 'actor');
  bind('#audit-target', 'target');

  root.querySelector('#audit-refresh')?.addEventListener('click', () => { view.page = 1; ctx.refresh(); toast('Filters applied'); });
  root.querySelector('#audit-prev')?.addEventListener('click', () => { view.page -= 1; ctx.refresh(); });
  root.querySelector('#audit-next')?.addEventListener('click', () => { view.page += 1; ctx.refresh(); });

  root.querySelector('#audit-verify')?.addEventListener('click', () => {
    view.verified = true;
    addAudit('audit.verify', 'audit-log', 'ok');
    save();
    toast('Audit chain verified — no gaps found', 'ok');
    ctx.refresh();
  });

  root.querySelector('#audit-purge')?.addEventListener('click', () => {
    toast('Purge requires owner re-authentication', 'err');
  });
}
