import { state } from '../store.js';
import { esc, fmtDate, fmtNum } from '../ui.js';

function visibleTransactions() {
  const owner = state.admin.role === 'owner';
  return (state.creditTransactions || [])
    .filter((tx) => owner || tx.user === state.admin.user)
    .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
}

export function render() {
  const rows = visibleTransactions();
  return `<section class="view-head">
    <div><h2>ประวัติการหักเครดิต</h2><p>ตรวจสอบรายการใช้เครดิตในการสร้างคีย์ย้อนหลัง</p></div>
    <div class="view-actions"><span class="badge">${fmtNum(rows.length)} รายการ</span></div>
  </section>
  <section class="card">
    <div class="table-tools">
      <input id="credit-search" class="search-in-card" placeholder="ค้นหารายการเครดิต…" aria-label="ค้นหารายการเครดิต">
    </div>
    ${rows.length ? `<div class="table-wrap"><table class="data-table" id="credit-table"><thead><tr>
      <th>วันที่</th><th>ผู้ใช้</th><th>รายการ</th><th>จำนวนคีย์</th><th>ราคา/คีย์</th><th>หักเครดิต</th><th>คงเหลือ</th><th>สถานะ</th>
    </tr></thead><tbody>${rows.map((tx) => `<tr>
      <td>${esc(fmtDate(tx.createdAt))}</td>
      <td><b>${esc(tx.user)}</b></td>
      <td>${esc(tx.durationLabel || 'สร้างคีย์')}<small class="sub">${esc(tx.source || 'ระบบ')}</small></td>
      <td>${fmtNum(tx.quantity || 0)}</td>
      <td>${fmtNum(tx.unitPrice || 0)} เครดิต</td>
      <td><strong class="credit-debit">-${fmtNum(tx.amount || 0)}</strong></td>
      <td>${tx.balanceAfter == null ? 'ไม่จำกัด' : `${fmtNum(tx.balanceAfter)} เครดิต`}</td>
      <td><span class="status active">สำเร็จ</span></td>
    </tr>`).join('')}</tbody></table></div>` : `<div class="empty-state"><div class="empty-icon">₡</div><h3>ยังไม่มีประวัติการหักเครดิต</h3><p>เมื่อสร้างคีย์สำเร็จ รายการจะถูกบันทึกไว้ที่หน้านี้</p></div>`}
  </section>`;
}

export function mount(host) {
  const input = host.querySelector('#credit-search');
  if (!input) return;
  input.addEventListener('input', () => {
    const query = input.value.trim().toLowerCase();
    host.querySelectorAll('#credit-table tbody tr').forEach((row) => {
      row.style.display = !query || row.textContent.toLowerCase().includes(query) ? '' : 'none';
    });
  });
}
