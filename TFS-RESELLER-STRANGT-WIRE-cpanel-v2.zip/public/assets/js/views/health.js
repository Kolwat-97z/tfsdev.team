/* System health: status pills and overview facts. */
import { state, statusCounts } from '../store.js';
import { icon, esc, fmtNum, fmtRelative } from '../ui.js';

export function render() {
  const counts = statusCounts();
  const facts = [
    ['Uptime', '99.98%'],
    ['API latency (p50)', '42 ms'],
    ['API latency (p95)', '118 ms'],
    ['Storage used', '184 MB'],
    ['Database size', '62 MB'],
    ['Keys stored', fmtNum(counts.all)],
    ['Devices bound', fmtNum(state.devices.length)],
    ['Audit entries', fmtNum(state.audit.length)],
    ['Last backup', fmtRelative(Date.now() - 4 * 3600000)],
    ['Build', 'v2.14.3 · production'],
    ['Node runtime', '22.11.0'],
    ['Region', 'sg2 · Singapore']
  ];

  return `
  <section class="view" data-view="health">
    <div class="section">
      <h2>${icon('pulse')}System Health</h2>
      <div class="pills" id="health-pills">
        ${state.health.map((h) => `<span class="pill ${h.tone}"><span class="dot"></span>${esc(h.label)} · ${esc(h.value)}</span>`).join('')}
      </div>
    </div>
    <div class="section">
      <h2>${icon('server')}Overview</h2>
      <div class="kv" id="health-kv">
        ${facts.map(([k, v]) => `<div><div class="k">${esc(k)}</div><div class="v">${esc(v)}</div></div>`).join('')}
      </div>
    </div>
  </section>`;
}

export function mount() {}
