/* Seller API: base URL, API keys, endpoint reference and examples. */
import { state, save, addAudit } from '../store.js';
import { icon, esc, fmtDate, fmtRelative, fmtNum, toast, copyText, badge, confirmDialog } from '../ui.js';

const baseUrl = () => 'https://strangewire.authzen.cc/api/seller';
let lastGenerated = null;

const EXAMPLES = [
  {
    title: 'สร้างคีย์',
    code: `curl -X POST "${baseUrl()}/key/create" \\
  -H "X-API-Key: <คีย์ที่ตั้งค่าไว้บนเซิร์ฟเวอร์>" \\
  -H "Content-Type: application/json" \\
  -d '{"duration":2592000,"max_devices":2,"quantity":1,"prefix":"HEX","note":"order #1024"}'`
  },
  {
    title: 'ตรวจสอบคีย์',
    code: `curl -X POST "${baseUrl()}/key/info" \\
  -H "X-API-Key: <คีย์ที่ตั้งค่าไว้บนเซิร์ฟเวอร์>" \\
  -H "Content-Type: application/json" \\
  -d '{"key":"HEX-XXXX-XXXX-XXXX"}'`
  },
  {
    title: 'Response',
    code: `{
  "success": true,
  "license": {
    "key": "SW-XXXX-XXXX-XXXX",
    "status": "active",
    "expires_at": "2026-12-20T10:00:00Z",
    "devices_used": 1,
    "devices_max": 2
  }
}`
  }
];

export function render() {
  return `
  <section class="view" data-view="api">
    <div class="section">
      <div class="api-hero">
        <h2>${icon('code')}Seller API</h2>
        <div class="api-url"><span>Base URL</span><b>${esc(baseUrl())}</b><button class="copy" data-copy="${esc(baseUrl())}">Copy</button></div>
      </div>
      <p class="card-sub" style="margin:0">ระบบใช้ API key จากไฟล์ตั้งค่าเพียงชุดเดียวผ่านเซิร์ฟเวอร์ ทุกคำขอจะส่ง <b style="color:var(--text)">X-API-Key</b> อัตโนมัติ หากคีย์ไม่ถูกต้อง API จะตอบกลับ <b style="color:var(--text)">401</b></p>
    </div>

    <div class="section">
      <div class="toolbar">
        <h2>${icon('key')}API Keys</h2>
        <span class="count">${state.apiKeys.length} keys</span>
      </div>
      <div class="row" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap">
        <div style="flex:1;min-width:220px">
          <label>API key ที่ใช้งาน</label>
          <input value="az_6d6f86b3…0100fa" readonly>
        </div>
        <span class="badge active" style="margin-bottom:7px">คีย์เดียวจากไฟล์ตั้งค่า</span>
      </div>
      <div id="ak-result" class="gen-box ${lastGenerated ? '' : 'hide'}">
        ${lastGenerated ? `<div class="head"><b>API key created</b><span class="muted">Copy it now — it is shown in full only once.</span></div>
          <code>${esc(lastGenerated)}</code>
          <div class="inline" style="margin-top:8px"><button class="ghost mini" data-copy-now>${icon('copy')}Copy key</button></div>` : ''}
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Name</th><th>API Key</th><th>Status</th><th>Created</th><th>Last used</th><th>Calls</th><th class="right">Actions</th></tr></thead>
          <tbody id="ak-rows" class="anim">
            ${state.apiKeys.map((k) => `<tr>
              <td><b style="font-weight:600">${esc(k.name)}</b></td>
              <td><span class="key">${esc(k.key.slice(0, 12))}…${esc(k.key.slice(-4))}</span></td>
              <td>${badge(k.status, k.status === 'active' ? 'Active' : 'Disabled')}</td>
              <td>${esc(fmtDate(k.createdAt))}</td>
              <td>${esc(fmtRelative(k.lastUsed))}</td>
              <td>${fmtNum(k.calls)}</td>
              <td class="actions-cell"><div class="row-actions">
                <button class="icon-btn" data-ak-copy="${k.id}" title="Copy key">${icon('copy')}</button>
                <button class="icon-btn ${k.status === 'active' ? 'danger' : ''}" data-ak-toggle="${k.id}" title="${k.status === 'active' ? 'Disable' : 'Enable'}">${icon(k.status === 'active' ? 'ban' : 'refresh')}</button>
                <button class="icon-btn danger" data-ak-del="${k.id}" title="Delete">${icon('trash')}</button>
              </div></td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
      ${state.apiKeys.length ? '' : '<p class="empty">No API keys yet. Generate one above.</p>'}
    </div>

    <div class="section">
      <h2>${icon('terminal')}Endpoints</h2>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Method</th><th>Path</th><th>Parameters (JSON)</th><th>Description</th></tr></thead>
          <tbody>
            ${state.endpoints.map((e) => `<tr>
              <td><span class="badge ${e.method === 'GET' ? 'lifetime' : 'active'}">${e.method}</span></td>
              <td><span class="key">${esc(e.path)}</span></td>
              <td><span class="key" style="color:var(--dim)">${esc(e.params)}</span></td>
              <td>${esc(e.desc)}</td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
      <div class="api-note"><b>Duration presets:</b> ${['1h', '1d', '7d', '30d', '90d', '365d', 'lifetime'].map((d) => `<span class="chip">${d}</span>`).join(' ')} · minimum validity is 1 hour (3600s).</div>
    </div>

    <div class="section">
      <h2>${icon('file-text')}Examples</h2>
      <div id="api-examples">
        ${EXAMPLES.map((ex) => `<div class="code-block">
          <div class="head"><span>${esc(ex.title)}</span><button class="copy" data-copy="${esc(ex.code)}">Copy</button></div>
          <pre style="margin:0;white-space:pre-wrap">${esc(ex.code)}</pre>
        </div>`).join('')}
      </div>
    </div>
  </section>`;
}

export function mount(root, ctx) {
  root.querySelectorAll('[data-copy]').forEach((btn) => btn.addEventListener('click', () => copyText(btn.dataset.copy)));

  root.querySelector('#ak-create')?.addEventListener('click', () => {
    const input = root.querySelector('#ak-name');
    const name = input.value.trim();
    if (!name) {
      input.focus();
      toast('Give the key a name first', 'err');
      return;
    }
    const raw = `sw_live_${Array.from({ length: 32 }, () => 'abcdefghijklmnopqrstuvwxyz0123456789'[Math.floor(Math.random() * 36)]).join('')}`;
    const entry = { id: `ak_${Date.now()}`, name, key: raw, status: 'active', createdAt: Date.now(), lastUsed: null, calls: 0 };
    state.apiKeys.unshift(entry);
    addAudit('api.key.create', name);
    save();
    lastGenerated = raw;
    input.value = '';
    toast('API key generated', 'ok');
    ctx.refresh();
  });

  root.querySelector('[data-copy-now]')?.addEventListener('click', () => { if (lastGenerated) copyText(lastGenerated); });

  root.querySelectorAll('[data-ak-copy]').forEach((btn) => btn.addEventListener('click', () => {
    const key = state.apiKeys.find((k) => k.id === btn.dataset.akCopy);
    if (key) copyText(key.key);
  }));

  root.querySelectorAll('[data-ak-toggle]').forEach((btn) => btn.addEventListener('click', () => {
    const key = state.apiKeys.find((k) => k.id === btn.dataset.akToggle);
    if (!key) return;
    key.status = key.status === 'active' ? 'disabled' : 'active';
    addAudit('api.key.toggle', key.name);
    save();
    toast(`Key ${key.status}`, 'ok');
    ctx.refresh();
  }));

  root.querySelectorAll('[data-ak-del]').forEach((btn) => btn.addEventListener('click', async () => {
    const key = state.apiKeys.find((k) => k.id === btn.dataset.akDel);
    if (!key) return;
    const ok = await confirmDialog({ title: 'Delete API key', message: `Delete the key owned by ${key.name}? Requests using it will start failing.`, confirmLabel: 'Delete', danger: true });
    if (!ok) return;
    state.apiKeys = state.apiKeys.filter((k) => k.id !== key.id);
    addAudit('api.key.delete', key.name);
    save();
    toast('API key deleted', 'ok');
    ctx.refresh();
  }));
}
