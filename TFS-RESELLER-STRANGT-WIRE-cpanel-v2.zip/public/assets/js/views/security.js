/* Security Center: password, two-factor, sessions. */
import { state, save, addAudit } from '../store.js';
import { icon, esc, fmtDateTime, fmtRelative, toast, copyText, confirmDialog } from '../ui.js';

const view = { enrolling: false, secret: '' };

function secret() {
  if (!view.secret) {
    view.secret = Array.from({ length: 32 }, () => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'[Math.floor(Math.random() * 32)]).join('');
  }
  return view.secret;
}

export function render() {
  return `
  <section class="view" data-view="security">
    <div class="two-col">
      <div class="section" id="pass-card">
        <h2>${icon('lock')}Change Password</h2>
        <div id="pass-form">
          <div class="row"><label for="p-current">Current password</label><input id="p-current" type="password" autocomplete="current-password"></div>
          <div class="row"><label for="p-new">New password</label><input id="p-new" type="password" placeholder="10+ chars, letters and numbers" autocomplete="new-password"></div>
          <button class="grad-btn" id="pass-btn">Update Password</button>
        </div>
        ${state.admin.defaultPassword ? `<p class="card-sub" style="margin:14px 0 0">${icon('alert')} You are still using the default password. Set a new one to remove the security banner.</p>` : ''}
      </div>

      <div class="section">
        <h2>${icon('fingerprint')}Two-Factor Authentication</h2>
        <p class="card-sub">${state.admin.twofa ? '2FA is on for your account.' : '2FA is off for your account.'}</p>
        ${view.enrolling ? `
          <p class="card-sub">Add this secret to your authenticator app, then confirm with a code:</p>
          <div class="api-url"><b>${esc(secret())}</b><button class="copy" data-copy-secret>Copy</button></div>
          <div class="row" style="margin-top:12px"><label for="twofa-code">Verification code</label><input id="twofa-code" inputmode="numeric" maxlength="6" placeholder="123456"></div>
          <div class="inline">
            <button class="grad-btn" id="twofa-confirm">Confirm &amp; enable</button>
            <button class="ghost" id="twofa-cancel">Cancel</button>
          </div>`
        : `<div class="inline">
            ${state.admin.twofa
              ? '<button class="ghost danger" id="twofa-disable">Disable 2FA</button>'
              : '<button class="grad-btn" id="twofa-enable">Enable 2FA</button>'}
          </div>`}
      </div>
    </div>

    <div class="section">
      <div class="toolbar">
        <h2>${icon('monitor')}Your Active Sessions</h2>
        <button class="ghost mini" id="sessions-revoke-all">Sign out all others</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>IP</th><th>Device</th><th>Created</th><th>Last seen</th><th class="right"></th></tr></thead>
          <tbody id="session-rows" class="anim">
            ${state.sessions.map((s) => `<tr>
              <td><span class="key">${esc(s.ip)}</span></td>
              <td>${esc(s.device)} ${s.current ? '<span class="badge active" style="margin-left:6px">this device</span>' : ''}</td>
              <td>${esc(fmtDateTime(s.created))}</td>
              <td>${esc(fmtRelative(s.lastSeen))}</td>
              <td class="actions-cell">${s.current ? '' : `<button class="ghost mini danger" data-revoke-session="${s.id}">Revoke</button>`}</td>
            </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>
  </section>`;
}

export function mount(root, ctx) {
  root.querySelector('#pass-btn')?.addEventListener('click', () => {
    const current = root.querySelector('#p-current').value;
    const next = root.querySelector('#p-new').value;
    if (current !== state.admin.password) { toast('Current password is incorrect', 'err'); return; }
    if (next.length < 10 || !/[a-z]/i.test(next) || !/\d/.test(next)) {
      toast('Use 10+ characters with letters and numbers', 'err');
      return;
    }
    state.admin.password = next;
    state.admin.defaultPassword = false;
    addAudit('auth.password', state.admin.user);
    save();
    toast('Password updated', 'ok');
    ctx.refresh();
  });

  root.querySelector('[data-copy-secret]')?.addEventListener('click', () => copyText(secret()));

  root.querySelector('#twofa-enable')?.addEventListener('click', () => {
    view.enrolling = true;
    ctx.refresh();
  });

  root.querySelector('#twofa-cancel')?.addEventListener('click', () => {
    view.enrolling = false;
    ctx.refresh();
  });

  root.querySelector('#twofa-confirm')?.addEventListener('click', () => {
    const code = root.querySelector('#twofa-code').value.trim();
    if (!/^\d{6}$/.test(code)) { toast('Enter the 6-digit code from your app', 'err'); return; }
    state.admin.twofa = true;
    view.enrolling = false;
    addAudit('auth.2fa.enable', state.admin.user);
    save();
    toast('Two-factor authentication enabled', 'ok');
    ctx.refresh();
  });

  root.querySelector('#twofa-disable')?.addEventListener('click', async () => {
    const ok = await confirmDialog({ title: 'Disable 2FA', message: 'Your account will only be protected by a password.', confirmLabel: 'Disable', danger: true });
    if (!ok) return;
    state.admin.twofa = false;
    addAudit('auth.2fa.disable', state.admin.user);
    save();
    toast('Two-factor authentication disabled', 'ok');
    ctx.refresh();
  });

  root.querySelectorAll('[data-revoke-session]').forEach((btn) => btn.addEventListener('click', () => {
    state.sessions = state.sessions.filter((s) => s.id !== btn.dataset.revokeSession);
    addAudit('auth.session.revoke', btn.dataset.revokeSession);
    save();
    toast('Session revoked', 'ok');
    ctx.refresh();
  }));

  root.querySelector('#sessions-revoke-all')?.addEventListener('click', () => {
    state.sessions = state.sessions.filter((s) => s.current);
    addAudit('auth.session.revoke_all', state.admin.user);
    save();
    toast('All other sessions signed out', 'ok');
    ctx.refresh();
  });
}
