/* Owner-only reseller management: one account, one API key, explicit role and credits. */
import { state, save, addAudit } from '../store.js';
import { icon, esc, fmtRelative, badge, toast, openModal, confirmDialog, copyText } from '../ui.js';

const ROLES = [['reseller', 'Reseller'], ['reseller_vip', 'Reseller VIP'], ['admin', 'Admin']];

export function render() {
  const canManage = state.admin.role === 'owner';
  return `
  <section class="view" data-view="users">
    <div class="page-head"><div><p class="card-sub">${canManage ? 'สร้างและจัดการบัญชีตัวแทน โดยผู้ใช้แต่ละคนจะมี API key แยกของตัวเอง' : 'รายชื่อบัญชีผู้ใช้'}</p></div><div class="tool-actions">${canManage ? `<button class="grad-btn" id="nu-open">${icon('user-plus')}เพิ่มตัวแทน</button>` : ''}</div></div>
    <div class="section table-card"><div class="table-wrap flush"><table>
      <thead><tr><th>ผู้ใช้</th><th>บทบาท</th><th>API key</th><th>เครดิต</th><th>2FA</th><th>สถานะ</th><th>เข้าสู่ระบบล่าสุด</th><th class="right">จัดการ</th></tr></thead>
      <tbody id="user-rows" class="anim">${state.admins.map((u) => `<tr>
        <td><div style="display:flex;align-items:center;gap:9px"><span class="avatar" style="width:28px;height:28px;font-size:11px">${esc(u.user.slice(0,2))}</span><div><b style="font-weight:600">${esc(u.name)}</b><span class="sub">${esc(u.email || '—')}</span></div></div></td>
        <td>${badge(u.role === 'owner' ? 'role' : u.role === 'reseller_vip' ? 'lifetime' : 'active', u.role)}</td>
        <td>${u.apiKey ? `<button class="key key-button" data-copy-api="${u.id}" title="Copy API key">${esc(u.apiKey.slice(0, 12))}…${esc(u.apiKey.slice(-4))}</button>` : '<span class="muted">ใช้คีย์ Owner</span>'}</td>
        <td><b>${u.role === 'reseller_vip' ? '∞' : fmtเครดิต(u.credits)}</b></td>
        <td>${u.twofa ? badge('active', 'เปิดใช้งาน') : badge('disabled', 'ปิด')}</td>
        <td>${badge(u.status === 'active' ? 'active' : 'disabled', u.status)}</td>
        <td>${esc(fmtRelative(u.lastLogin))}</td>
        <td class="actions-cell"><div class="row-actions"><button class="icon-btn" data-user-toggle="${u.id}" title="${u.status === 'active' ? 'Suspend' : 'Activate'}">${icon(u.status === 'active' ? 'ban' : 'refresh')}</button><button class="icon-btn danger" data-user-del="${u.id}" title="ลบ" ${u.role === 'owner' ? 'disabled' : ''}>${icon('trash')}</button></div></td>
      </tr>`).join('')}</tbody>
    </table></div></div>
  </section>`;
}

function fmtเครดิต(value) { return Number(value || 0).toLocaleString('en-US'); }

export function mount(root, ctx) {
  root.querySelectorAll('[data-copy-api]').forEach((btn) => btn.addEventListener('click', () => { const u = state.admins.find((x) => x.id === btn.dataset.copyApi); if (u?.apiKey) copyText(u.apiKey); }));
  root.querySelector('#nu-open')?.addEventListener('click', () => {
    openModal({
      title: 'เพิ่มตัวแทน', subtitle: 'ผู้ใช้หนึ่งคนจะได้รับ API key แยกหนึ่งชุด ระบบจะแสดงคีย์เต็มเพียงครั้งเดียว', wide: true,
      body: `<form id="nu-form"><div class="grid two"><div><label for="nu-user">ชื่อผู้ใช้</label><input id="nu-user" placeholder="เช่น reseller_a" autocomplete="off"></div><div><label for="nu-name">ชื่อที่แสดง</label><input id="nu-name" placeholder="เช่น Reseller A"></div></div><div class="grid two"><div><label for="nu-pass">รหัสผ่าน</label><input id="nu-pass" type="password" placeholder="อย่างน้อย 10 ตัวอักษร" autocomplete="new-password"></div><div><label for="nu-role">บทบาท</label><select id="nu-role">${ROLES.map(([v,l]) => `<option value="${v}">${l}</option>`).join('')}</select></div></div><div class="grid two"><div><label for="nu-credits">เครดิตเริ่มต้น</label><input id="nu-credits" type="number" min="0" value="100"></div><div><label for="nu-email">อีเมล (ไม่บังคับ)</label><input id="nu-email" type="email" placeholder="name@company.com"></div></div><div><label for="nu-api">API key ของผู้ใช้นี้ (ไม่บังคับ)</label><input id="nu-api" placeholder="เว้นว่าง = ใช้ API key เดียวกับ Owner" autocomplete="off"></div><div class="info-box">ผู้ใช้แต่ละคนมี API key ได้ 1 ชุด หากไม่กรอกจะใช้คีย์หลักของ Owner อัตโนมัติ</div></form>`,
      footer: '<button class="ghost" data-close>ยกเลิก</button><button class="grad-btn" id="nu-create">สร้างตัวแทน</button>',
      onMount(modal, close) {
        modal.querySelector('#nu-create').addEventListener('click', () => {
          const user = modal.querySelector('#nu-user').value.trim().toLowerCase(); const pass = modal.querySelector('#nu-pass').value;
          const role = modal.querySelector('#nu-role').value; const credits = Math.max(0, Number(modal.querySelector('#nu-credits').value) || 0);
          if (!/^[a-z0-9_.-]{3,32}$/.test(user)) { toast('ผู้ใช้name must be 3-32 chars: a-z 0-9 _ . -', 'err'); return; }
          if (pass.length < 10) { toast('รหัสผ่าน needs at least 10 characters', 'err'); return; }
          if (state.admins.some((a) => a.user === user)) { toast('That username already exists', 'err'); return; }
          const apiKey = modal.querySelector('#nu-api').value.trim() || null;
          if (apiKey && !apiKey.startsWith('az_')) { toast('API key ต้องขึ้นต้นด้วย az_', 'err'); return; }
          state.admins.push({ id:`u_${Date.now()}`, user, name:modal.querySelector('#nu-name').value.trim() || user, email:modal.querySelector('#nu-email').value.trim() || '—', password:pass, role, credits, apiKey, apiKeySource: apiKey ? 'manual' : 'owner-fallback', twofa:false, status:'active', lastLogin:null });
          addAudit('users.create_reseller', user); save(); close(); toast(`Reseller ${user} created`, 'ok'); ctx.refresh();
        });
      }
    });
  });
  root.querySelectorAll('[data-user-toggle]').forEach((btn) => btn.addEventListener('click', () => { const user = state.admins.find((u) => u.id === btn.dataset.userToggle); if (!user || user.role === 'owner') return; user.status = user.status === 'active' ? 'suspended' : 'active'; addAudit('users.status', user.user); save(); toast(`${user.user} ${user.status}`, 'ok'); ctx.refresh(); }));
  root.querySelectorAll('[data-user-del]').forEach((btn) => btn.addEventListener('click', async () => { const user = state.admins.find((u) => u.id === btn.dataset.userDel); if (!user || user.role === 'owner') return; const ok = await confirmDialog({ title:'ลบตัวแทน', message:`ลบ ${user.user} and และยกเลิก API key ของผู้ใช้นี้หรือไม่?`, confirmLabel:'ลบ', danger:true }); if (!ok) return; state.admins = state.admins.filter((u) => u.id !== user.id); addAudit('users.delete', user.user); save(); toast('Reseller removed', 'ok'); ctx.refresh(); }));
}
