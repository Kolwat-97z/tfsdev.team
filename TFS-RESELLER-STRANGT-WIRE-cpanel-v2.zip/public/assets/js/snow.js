/* Low-cost decorative snow: a small fixed pool of CSS-animated flakes. */
let host;

export function stopSnow() {
  host?.remove();
  host = null;
}

export function startSnow(enabled = true) {
  stopSnow();
  if (!enabled || window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;
  host = document.createElement('div');
  host.className = 'snow-layer';
  host.setAttribute('aria-hidden', 'true');
  const count = window.matchMedia?.('(max-width: 600px)').matches ? 14 : 24;
  for (let i = 0; i < count; i += 1) {
    const flake = document.createElement('i');
    flake.className = 'snowflake';
    flake.style.left = `${(i * 41) % 101}%`;
    flake.style.animationDelay = `${(i % 9) * -1.4}s`;
    flake.style.animationDuration = `${8 + (i % 5)}s`;
    flake.style.opacity = `${0.25 + (i % 5) * 0.1}`;
    flake.style.setProperty('--drift', `${((i % 7) - 3) * 18}px`);
    host.appendChild(flake);
  }
  document.body.appendChild(host);
}
