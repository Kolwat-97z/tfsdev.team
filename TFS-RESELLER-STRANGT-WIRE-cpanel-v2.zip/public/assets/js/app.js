/* App shell: authentication, routing, topbar, command palette, key creation. */
import {
  state, save, getSession, startSession, endSession, getTheme, setTheme,
  statusCounts, statusOf, durationLabel, addAudit, makeKey, DURATIONS
} from './store.js';
import {
  icon, esc, fmtNum, fmtDate, toast, openModal, closeModal, closeDrawer, copyText, openDrawer
} from './ui.js';

import * as dashboard from './views/dashboard.js?v=credit-overview-1';
import * as licenses from './views/licenses.js';
import * as devices from './views/devices.js';
import * as api from './views/api.js';
import * as control from './views/control.js';
import * as functions from './views/functions.js';
import * as logs from './views/logs.js';
import * as users from './views/users.js';
import * as security from './views/security.js';
import * as settings from './views/settings.js';
import * as health from './views/health.js';
import * as contact from './views/contact.js';
import { startSnow } from './snow.js';
import * as creditHistory from './views/credit-history.js';
import { syncSellerData, createSellerKeys } from './seller-api.js';

const ROUTES = {
  dashboard: { module: dashboard, title: 'แดชบอร์ด', sub: 'ภาพรวมระบบและกิจกรรมล่าสุด' },
  licenses: { module: licenses, title: 'รายการคีย์', sub: 'สร้าง ต่ออายุ และยกเลิกคีย์' },
  devices: { module: devices, title: 'อุปกรณ์', sub: 'ฮาร์ดแวร์ที่ผูกกับคีย์' },
  api: { module: api, title: 'จัดการ API', sub: 'API key และเอกสารการเชื่อมต่อ' },
  control: { module: control, title: 'แผงควบคุม', sub: 'ตั้งค่าฟีเจอร์ตามระดับผู้ใช้' },
  functions: { module: functions, title: 'ฟังก์ชัน', sub: 'รายการฟังก์ชันของผู้ใช้' },
  logs: { module: logs, title: 'บันทึกกิจกรรม', sub: 'ประวัติการทำงานของระบบ' },
  users: { module: users, title: 'ผู้ใช้และบทบาท', sub: 'จัดการ Owner และตัวแทนจำหน่าย' },
  security: { module: security, title: 'ความปลอดภัย', sub: 'รหัสผ่าน 2FA และเซสชัน' },
  'credit-history': { module: creditHistory, title: 'ประวัติเครดิต', sub: 'ประวัติการหักเครดิตย้อนหลัง' },
  settings: { module: settings, title: 'ตั้งค่าทั่วไป', sub: 'แบรนด์ ค่าเริ่มต้น และโหมดบำรุงรักษา' },
  health: { module: health, title: 'สุขภาพระบบ', sub: 'พื้นที่จัดเก็บ ฐานข้อมูล และ uptime' },
  contact: { module: contact, title: 'ติดต่อทีมงาน', sub: 'Discord และ Telegram' }
};

const SEARCH_TARGETS = {
  dashboard: null, licenses: '#key-search', devices: '#device-search', api: null,
  control: '#cp-q', functions: '#fn-q', logs: '#audit-action', users: null,
  security: null, 'credit-history': '#credit-search', settings: null, health: null, contact: null
};

let currentView = 'dashboard';
let paletteIndex = 0;
let paletteItems = [];
let sessionTimer = null;
let remaining = 30 * 60;

const root = () => document.getElementById('view-root');

/* Site-wide loading screen shown on boot and on every page change. */
let loaderTimer = null;
function showLoader() {
  const el = document.getElementById('site-loader');
  if (!el) return;
  clearTimeout(loaderTimer);
  el.classList.remove('hide');
}
function hideLoader(delay = 420) {
  const el = document.getElementById('site-loader');
  if (!el) return;
  clearTimeout(loaderTimer);
  loaderTimer = setTimeout(() => el.classList.add('hide'), delay);
}
const app = () => document.getElementById('app');
const RESELLER_PAGES = new Set(['dashboard', 'licenses', 'create', 'devices', 'security', 'credit-history', 'contact']);
const CREDIT_PRICES = { 3600: 1, 10800: 2, 21600: 3, 43200: 4, 86400: 5, 259200: 8, 604800: 14, 1296000: 20, 2592000: 45 };
const PRICE_LABELS = [['1 hour', 3600], ['3 hours', 10800], ['6 hours', 21600], ['12 hours', 43200], ['1 day', 86400], ['3 days', 259200], ['7 days', 604800], ['15 days', 1296000], ['30 days', 2592000]];
const isOwner = () => state.admin.role === 'owner';
const canAccess = (view) => isOwner() || RESELLER_PAGES.has(view);
const visibleKeyCount = () => isOwner() ? state.keys.length : state.keys.filter((k) => state.sellerOwnership?.[k.key] === state.admin.user).length;
function updateCreditDisplay() {
  const el = document.getElementById('me-credits');
  if (!el) return;
  const unlimited = state.admin.role === 'owner' || state.admin.role === 'reseller_vip';
  el.textContent = unlimited ? 'เครดิต: ไม่จำกัด' : `เครดิต: ${fmtNum(state.admin.credits ?? 0)}`;
}

function applyRoleVisibility() {
  const nav = document.getElementById('nav');
  if (!nav) return;
  nav.querySelectorAll('.nav-item[data-view]').forEach((item) => {
    const visible = isOwner() || RESELLER_PAGES.has(item.dataset.view);
    item.style.display = visible ? '' : 'none';
  });
  nav.querySelectorAll('.nav-label').forEach((label) => {
    let sibling = label.nextElementSibling;
    let visible = false;
    while (sibling && !sibling.classList.contains('nav-label')) {
      if (sibling.matches('.nav-item[data-view]') && sibling.style.display !== 'none') visible = true;
      sibling = sibling.nextElementSibling;
    }
    label.style.display = visible ? '' : 'none';
  });
}

/* ───────────────────────── auth ───────────────────────── */
function showApp() {
  document.getElementById('login').classList.add('hide');
  app().classList.remove('hide');
  const me = state.admin;
  document.getElementById('me-name').textContent = me.name;
  document.getElementById('me-role').textContent = me.role;
  document.getElementById('me-avatar').textContent = me.name.slice(0, 2);
  updateCreditDisplay();
  document.getElementById('nav-key-count').textContent = fmtNum(visibleKeyCount());
  startSessionTimer();
  startSnow(state.settings.snowEnabled);
  const initial = location.hash.replace('#', '') || 'dashboard';
  navigate(initial === 'create' ? 'licenses' : initial, { replace: true });
  if (initial === 'create') setTimeout(openCreateKeys, 120);
  syncSellerData().then(() => render()).catch((error) => toast(`Seller API: ${error.message}`, 'err'));
}

function showLogin() {
  app().classList.add('hide');
  document.getElementById('login').classList.remove('hide');
  clearInterval(sessionTimer);
  const input = document.getElementById('admin-user');
  if (input) input.focus();
}

let attempts = 0;

function handleLogin(event) {
  event.preventDefault();
  const form = document.getElementById('login-form');
  const user = document.getElementById('admin-user').value.trim().toLowerCase();
  const pass = document.getElementById('admin-pass').value;
  const error = document.getElementById('login-error');
  const message = error.querySelector('span');

  const fail = (text) => {
    message.textContent = text;
    error.classList.remove('hide');
    form.classList.remove('shake');
    void form.offsetWidth;
    form.classList.add('shake');
    document.getElementById('admin-pass').select();
  };

  if (!user || !pass) { fail('Enter both your username and password.'); return; }
  if (attempts >= 5) { fail('Too many attempts. This panel is locked for 60 seconds.'); return; }

  const account = state.admins?.find((candidate) => candidate.user === user && candidate.password === pass && candidate.status === 'active');
  if (account || (user === state.admin.user && pass === state.admin.password)) {
    attempts = 0;
    error.classList.add('hide');
    if (account) {
      state.admin = {
        ...state.admin,
        user: account.user,
        name: account.name,
        email: account.email,
        role: account.role,
        password: account.password,
        credits: account.credits ?? null,
        apiKey: account.apiKey ?? null,
        twofa: account.twofa,
        defaultPassword: account.user === 'tfs' && account.password === 'tfs-pass'
      };
      account.lastLogin = Date.now();
      save();
    }
    startSession({ user: state.admin.user, role: state.admin.role, name: state.admin.name });
    addAudit('auth.login', user, 'ok');
    document.getElementById('login-form').reset();
    document.getElementById('pw-toggle').textContent = 'Show';
    document.getElementById('admin-pass').type = 'password';
    showApp();
    toast('Signed in', 'ok');
  } else {
    attempts += 1;
    addAudit('auth.login', user || 'unknown', 'denied');
    fail(`Incorrect username or password. ${5 - attempts} attempt${5 - attempts === 1 ? '' : 's'} left.`);
  }
}

function logout() {
  endSession();
  addAudit('auth.logout', state.admin.user);
  closeDrawer();
  closeModal();
  showLogin();
  toast('Signed out');
}

/* ───────────────────────── router ───────────────────────── */
export function navigate(view, { replace = false } = {}) {
  if (!canAccess(view)) view = 'dashboard';
  if (!ROUTES[view]) view = 'dashboard';
  currentView = view;
  if (replace) history.replaceState(null, '', `#${view}`);
  else location.hash = `#${view}`;
  showLoader();
  render();
  hideLoader();
}

function render(opts = {}) {
  applyRoleVisibility();
  const route = ROUTES[currentView] || ROUTES.dashboard;
  document.getElementById('page-title').textContent = route.title;
  document.getElementById('page-sub').textContent = route.sub;
  document.querySelectorAll('.nav-item[data-view]').forEach((item) => {
    item.classList.toggle('active', item.dataset.view === currentView);
  });
  document.getElementById('page-search').placeholder = `Search ${route.title.toLowerCase()}…  ( / )`;

  const banner = state.admin.defaultPassword ? `
    <div class="banner">
      <span>⚠ <b>ความปลอดภัย:</b> คุณกำลังใช้รหัสผ่านเริ่มต้น ควรเปลี่ยนรหัสผ่านเพื่อป้องกันแผงควบคุม</span>
      <button class="ghost mini" data-action="goto" data-view="security">เปิดหน้าความปลอดภัย</button>
    </div>` : '';

  const host = root();
  host.innerHTML = `${banner}${route.module.render()}`;
  route.module.mount?.(host, { refresh: (o) => render(o), navigate, openKey });

  if (opts.keepFocus) {
    const input = host.querySelector(opts.keepFocus);
    if (input) {
      input.focus();
      if (opts.caret != null) input.setSelectionRange(opts.caret, opts.caret);
    }
  }
  document.getElementById('nav-key-count').textContent = fmtNum(visibleKeyCount());
  updateCreditDisplay();
}

function openKey(id) {
  const key = state.keys.find((k) => k.id === id);
  if (!key) return;
  openDrawer(key.key, licenses.detailHtml(key));
  document.getElementById('drawer-body').dataset.key = key.key;
}

/* ───────────────────────── theme ───────────────────────── */
function applyTheme(mode) {
  document.documentElement.dataset.theme = mode;
  document.querySelectorAll('#theme-seg .seg-btn').forEach((btn) => {
    btn.setAttribute('aria-pressed', String(btn.dataset.mode === mode));
  });
}

/* ───────────────────────── session timer ───────────────────────── */
function startSessionTimer() {
  clearInterval(sessionTimer);
  remaining = 30 * 60;
  const label = document.getElementById('session-timer');
  const tick = () => {
    remaining = Math.max(0, remaining - 1);
    const m = String(Math.floor(remaining / 60)).padStart(2, '0');
    const s = String(remaining % 60).padStart(2, '0');
    if (label) label.textContent = `Session ${m}:${s}`;
    if (remaining === 0) { clearInterval(sessionTimer); logout(); toast('Signed out after inactivity', 'err'); }
  };
  tick();
  sessionTimer = setInterval(tick, 1000);
  ['pointerdown', 'keydown'].forEach((evt) => window.addEventListener(evt, () => { remaining = 30 * 60; }, { passive: true }));
}

/* ───────────────────────── create keys ───────────────────────── */
function maskPreview(mask) {
  return mask.replace(/\*/g, () => 'A');
}

export function openCreateKeys() {
  const defaults = state.settings;
  const mask = `${defaults.prefix}-****-****-****`;
  openModal({
    title: 'Create Keys',
    subtitle: "Keys start counting down on the buyer's first connect.",
    wide: true,
    body: `<form id="ck-form">
      <div class="grid two">
        <div><label for="ck-amount">Amount</label><input id="ck-amount" type="number" min="1" max="100" value="1"></div>
        <div><label for="ck-devices">Device limit (HWID)</label><input id="ck-devices" type="number" min="1" max="20" value="${defaults.defaultDevices}"></div>
      </div>
      <div class="row">
        <label for="ck-mask">Key mask <span class="muted">— <code>*</code> = random character</span></label>
        <input id="ck-mask" value="${esc(mask)}">
        <p class="hint">Preview: <code id="ck-preview">${esc(maskPreview(mask))}</code></p>
      </div>
      <div class="row">
        <label for="ck-dur">Duration</label>
        <div class="inline">
          <input id="ck-dur" type="number" min="1" value="1">
          <select id="ck-unit">
            ${PRICE_LABELS.map(([label, seconds]) => `<option value="${seconds}" ${seconds === 2592000 ? 'selected' : ''}>${label} · ${CREDIT_PRICES[seconds]} เครดิต</option>`).join('')}
          </select>
          <label class="chk-line"><input id="ck-lifetime" type="checkbox">Lifetime</label>
        </div>
        <div class="chips" id="ck-presets">
          ${PRICE_LABELS.map(([label, seconds]) => `<button type="button" class="chip" data-preset="${seconds}">${label}</button>`).join('')}
        </div>
        <p class="hint" id="ck-cost">Cost per key 45 credits · Total 45 credits</p>
      </div>
      <div class="row">
        <label for="ck-note">Note (optional)</label>
        <input id="ck-note" placeholder="e.g. order #1024, reseller batch">
      </div>
      <details class="adv">
        <summary>Advanced</summary>
        <div class="row" style="margin-top:10px">
          <label for="ck-custom">Custom key value</label>
          <input id="ck-custom" placeholder="e.g. MYSHOP-PREMIUM-001 (creates exactly one key)">
        </div>
      </details>
    </form>`,
    footer: '<button class="ghost" data-close>Cancel</button><button class="grad-btn" id="ck-submit">Create Keys</button>',
    onMount(modal, close) {
      const maskInput = modal.querySelector('#ck-mask');
      const preview = modal.querySelector('#ck-preview');
      maskInput.addEventListener('input', () => { preview.textContent = maskPreview(maskInput.value); });
      const updateCost = () => {
        const unit = Number(modal.querySelector('#ck-unit').value);
        const amount = Math.max(1, Number(modal.querySelector('#ck-amount').value) || 1);
        const price = CREDIT_PRICES[unit] || 0;
        modal.querySelector('#ck-cost').textContent = modal.querySelector('#ck-lifetime').checked ? 'Lifetime · no credits charged' : `Cost per key ${price} credits · Total ${price * amount} credits`;
      };
      ['#ck-unit', '#ck-amount', '#ck-lifetime'].forEach((selector) => modal.querySelector(selector).addEventListener('input', updateCost));
      updateCost();

      modal.querySelectorAll('[data-preset]').forEach((chip) => chip.addEventListener('click', () => {
        const seconds = Number(chip.dataset.preset);
        modal.querySelector('#ck-lifetime').checked = false;
        modal.querySelector('#ck-dur').value = 1;
        modal.querySelector('#ck-unit').value = String(seconds);
        updateCost();
      }));

      modal.querySelector('#ck-submit').addEventListener('click', async () => {
        const custom = modal.querySelector('#ck-custom').value.trim();
        const amount = custom ? 1 : Math.min(100, Math.max(1, Number(modal.querySelector('#ck-amount').value) || 1));
        const devices = Math.max(1, Number(modal.querySelector('#ck-devices').value) || 1);
        const unit = Number(modal.querySelector('#ck-unit').value);
        const lifetime = modal.querySelector('#ck-lifetime').checked;
        const duration = CREDIT_PRICES[unit] ? unit : Math.max(3600, (Number(modal.querySelector('#ck-dur').value) || 1) * unit);
        const note = modal.querySelector('#ck-note').value.trim();
        const maskValue = modal.querySelector('#ck-mask').value.trim() || `${state.settings.prefix}-****-****-****`;
        const unitPrice = lifetime ? 0 : (CREDIT_PRICES[unit] || 0);
        const charge = unitPrice * amount;
        const unlimited = state.admin.role === 'owner' || state.admin.role === 'reseller_vip';

        if (custom) { toast('Seller API รองรับ prefix เท่านั้น ไม่รองรับกำหนดคีย์เอง', 'err'); return; }
        if (!unlimited && Number(state.admin.credits || 0) < charge) { toast(`เครดิตไม่พอ ต้องใช้ ${charge} เครดิต แต่เหลือ ${state.admin.credits || 0} เครดิต`, 'err'); return; }
        const submit = modal.querySelector('#ck-submit');
        submit.disabled = true;
        try {
          const created = await createSellerKeys({ duration: lifetime ? 31536000 : duration, maxDevices: devices, quantity: amount, prefix: maskValue.split('-')[0] || state.settings.prefix, note });
          const actualCharge = unlimited ? 0 : unitPrice * (created.length || amount);
          if (!unlimited) {
            state.admin.credits = Math.max(0, Number(state.admin.credits || 0) - actualCharge);
            const account = state.admins.find((u) => u.user === state.admin.user);
            if (account) account.credits = state.admin.credits;
            updateCreditDisplay();
          }
          if (state.admin.role === 'reseller' || state.admin.role === 'reseller_vip') {
            state.creditTransactions.unshift({
              id: `ct_${Date.now()}`,
              user: state.admin.user,
              type: 'debit',
              duration: lifetime ? null : duration,
              durationLabel: lifetime ? 'ถาวร' : (PRICE_LABELS.find(([, seconds]) => seconds === unit)?.[0] || durationLabel(duration)),
              quantity: created.length || amount,
              unitPrice,
              amount: actualCharge,
              balanceAfter: unlimited ? null : state.admin.credits,
              source: 'สร้างคีย์ผ่าน Seller API',
              createdAt: Date.now()
            });
          }
          save();
          addAudit('keys.create', `${created.length} keys via Seller API`);
          showCreatedKeys(modal, close, created);
          toast(`${created.length} คีย์ถูกสร้างผ่าน Seller API`, 'ok');
          if (currentView === 'licenses' || currentView === 'dashboard') render();
        } catch (error) {
          submit.disabled = false;
          toast(`สร้างคีย์ไม่สำเร็จ: ${error.message}`, 'err');
        }
      });
    }
  });
}

function showCreatedKeys(modal, close, created) {
  const body = modal.querySelector('.dlg-body');
  const foot = modal.querySelector('.modal-foot');
  body.innerHTML = `<div class="gen-box" style="margin:0">
    <div class="head"><b>${created.length} key${created.length === 1 ? '' : 's'} created</b>
      <div class="actions">
        <button class="ghost mini" id="ck-copy">${icon('copy')}Copy all</button>
        <button class="ghost mini" id="ck-download">${icon('download')}Download .txt</button>
      </div></div>
    <div class="ck-list">${created.map((k) => `<code>${esc(k.key)}</code>`).join('')}</div>
  </div>`;
  foot.innerHTML = '<button class="ghost" id="ck-again">Create more</button><button class="grad-btn" data-close>Done</button>';
  foot.querySelector('[data-close]').addEventListener('click', close);
  modal.querySelectorAll('[data-close]').forEach((btn) => btn.addEventListener('click', close));
  body.querySelector('#ck-copy').addEventListener('click', () => copyText(created.map((k) => k.key).join('\n')));
  body.querySelector('#ck-download').addEventListener('click', () => {
    const blob = new Blob([created.map((k) => k.key).join('\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `strange-wair-keys-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  });
  foot.querySelector('#ck-again').addEventListener('click', () => { closeModal(); setTimeout(openCreateKeys, 60); });
}

/* ───────────────────────── command palette ───────────────────────── */
const PAGES = Object.entries(ROUTES).map(([id, r]) => ({ id, label: r.title, hint: 'Page', action: () => navigate(id) }));

function paletteSource() {
  const items = PAGES.filter((item) => canAccess(item.id));
  items.push(
    { label: 'Create keys', hint: 'Action', action: openCreateKeys },
    { label: 'Toggle day / night theme', hint: 'Action', action: () => toggleTheme() },
    { label: 'Verify audit chain', hint: 'Action', action: () => navigate('logs') },
    { label: 'Sign out', hint: 'Action', action: logout }
  );
  state.keys.slice(0, 8).forEach((k) => items.push({ label: k.key, hint: `Key · ${statusOf(k)}`, mono: true, action: () => openKey(k.id) }));
  state.devices.slice(0, 5).forEach((d) => items.push({ label: d.hwid, hint: `Device · ${d.key}`, mono: true, action: () => navigate('devices') }));
  state.admins.forEach((u) => items.push({ label: `@${u.user}`, hint: `Admin · ${u.role}`, action: () => navigate('users') }));
  state.apiKeys.forEach((k) => items.push({ label: k.name, hint: 'API key', action: () => navigate('api') }));
  return items;
}

function openPalette() {
  const box = document.getElementById('cmdk');
  box.setAttribute('aria-hidden', 'false');
  const input = document.getElementById('cmdk-input');
  input.value = '';
  paletteIndex = 0;
  drawPalette('');
  setTimeout(() => input.focus(), 30);
}

function closePalette() {
  document.getElementById('cmdk').setAttribute('aria-hidden', 'true');
}

function drawPalette(query) {
  const q = query.trim().toLowerCase();
  paletteItems = paletteSource().filter((item) => !q || `${item.label} ${item.hint}`.toLowerCase().includes(q)).slice(0, 24);
  paletteIndex = Math.min(paletteIndex, Math.max(0, paletteItems.length - 1));
  const list = document.getElementById('cmdk-list');
  if (!paletteItems.length) {
    list.innerHTML = '<li class="cmdk-empty">No matches. Try a key, device or page name.</li>';
    return;
  }
  list.innerHTML = paletteItems.map((item, i) => `<li class="cmdk-item ${i === paletteIndex ? 'on' : ''}" data-index="${i}">
    <span class="${item.mono ? 'mono' : ''}">${esc(item.label)}</span><small>${esc(item.hint)}</small></li>`).join('');
  list.querySelectorAll('.cmdk-item').forEach((li) => li.addEventListener('click', () => runPalette(Number(li.dataset.index))));
}

function runPalette(index) {
  const item = paletteItems[index];
  if (!item) return;
  closePalette();
  item.action();
}

/* ───────────────────────── theme toggle ───────────────────────── */
function toggleTheme(mode) {
  const next = mode || (document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
  applyTheme(next);
  setTheme(next);
}

/* ───────────────────────── boot ───────────────────────── */
function boot() {
  applyTheme('dark');
  setTheme('dark');

  document.getElementById('login-form').addEventListener('submit', handleLogin);

  const pass = document.getElementById('admin-pass');
  document.getElementById('pw-toggle').addEventListener('click', () => {
    const showing = pass.type === 'text';
    pass.type = showing ? 'password' : 'text';
    document.getElementById('pw-toggle').textContent = showing ? 'Show' : 'Hide';
    pass.focus();
  });

  pass.addEventListener('keyup', (event) => {
    document.getElementById('caps-hint').classList.toggle('hide', !event.getModifierState?.('CapsLock'));
  });

  document.getElementById('logout').addEventListener('click', logout);
  document.getElementById('nav-toggle').addEventListener('click', () => {
    const open = app().classList.toggle('nav-open');
    document.getElementById('nav-toggle').setAttribute('aria-expanded', String(open));
  });

  document.querySelectorAll('.nav-item[data-view]').forEach((item) => {
    item.addEventListener('click', () => {
      app().classList.remove('nav-open');
      if (item.dataset.view === 'create') { openCreateKeys(); return; }
      navigate(item.dataset.view);
    });
  });

  document.getElementById('theme-seg').addEventListener('click', (event) => {
    const btn = event.target.closest('[data-mode]');
    if (btn) toggleTheme(btn.dataset.mode);
  });

  document.getElementById('page-search').addEventListener('input', (event) => {
    const target = SEARCH_TARGETS[currentView];
    if (!target) {
      const value = event.target.value.trim().toLowerCase();
      const first = root().querySelector('tbody tr');
      if (first) first.style.display = value && !first.textContent.toLowerCase().includes(value) ? 'none' : '';
      return;
    }
    const input = root().querySelector(target);
    if (!input) return;
    input.value = event.target.value;
    input.dispatchEvent(new Event('input', { bubbles: true }));
  });

  document.getElementById('cmdk-open').addEventListener('click', openPalette);
  const cmdkInput = document.getElementById('cmdk-input');
  cmdkInput.addEventListener('input', () => drawPalette(cmdkInput.value));
  document.getElementById('cmdk').addEventListener('click', (event) => {
    if (event.target.id === 'cmdk') closePalette();
  });

  document.getElementById('drawer-close').addEventListener('click', closeDrawer);
  document.getElementById('drawer').addEventListener('click', (event) => {
    if (event.target.id === 'drawer') closeDrawer();
  });
  document.getElementById('drawer-body').addEventListener('click', (event) => {
    const btn = event.target.closest('[data-drawer-act]');
    if (!btn) return;
    document.dispatchEvent(new CustomEvent('sw:drawer-act', {
      detail: { action: btn.dataset.drawerAct, key: document.getElementById('drawer-body').dataset.key }
    }));
  });

  document.addEventListener('click', (event) => {
    const goto = event.target.closest('[data-action="goto"]');
    if (goto) { navigate(goto.dataset.view); return; }
    if (event.target.closest('[data-action="create-keys"]')) openCreateKeys();
  });

  document.addEventListener('sw:refresh', () => render());

  document.addEventListener('keydown', (event) => {
    const typing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName);
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      openPalette();
      return;
    }
    if (event.key === '/' && !typing) {
      event.preventDefault();
      document.getElementById('page-search').focus();
      return;
    }
    const paletteOpen = document.getElementById('cmdk').getAttribute('aria-hidden') === 'false';
    if (paletteOpen) {
      if (event.key === 'ArrowDown') { event.preventDefault(); paletteIndex = Math.min(paletteIndex + 1, paletteItems.length - 1); drawPalette(cmdkInput.value); }
      if (event.key === 'ArrowUp') { event.preventDefault(); paletteIndex = Math.max(0, paletteIndex - 1); drawPalette(cmdkInput.value); }
      if (event.key === 'Enter') { event.preventDefault(); runPalette(paletteIndex); }
      if (event.key === 'Escape') closePalette();
      return;
    }
    if (event.key === 'Escape') { closeDrawer(); closeModal(); }
  });

  window.addEventListener('hashchange', () => {
    const view = location.hash.replace('#', '') || 'dashboard';
    if (view === 'create') { openCreateKeys(); return; }
    if (ROUTES[view] && view !== currentView) {
      if (!canAccess(view)) { navigate('dashboard', { replace: true }); return; }
      currentView = view; showLoader(); render(); hideLoader();
    }
  });

  if (getSession()) {
    showApp();
  } else {
    showLogin();
  }
  hideLoader(500);
}

boot();
