import { state, save } from './store.js';

// Keep the API path relative so cPanel apps mounted at /reseller also resolve correctly.
const endpoint = (path) => `api/seller/${path}`;

async function call(path, options = {}) {
  const headers = { Accept: 'application/json', 'X-Seller-API-Key': state.admin.apiKey || '', ...(options.body ? { 'Content-Type': 'application/json' } : {}) };
  const response = await fetch(endpoint(path), { ...options, headers: { ...headers, ...(options.headers || {}) } });
  const rawBody = await response.text();
  let data = null;
  try { data = rawBody ? JSON.parse(rawBody) : null; } catch { data = null; }
  if (!response.ok || data?.status === 'error') {
    const safeBody = (data?.message || data?.error || rawBody || 'Empty response').replace(/(x[-_ ]?seller[-_ ]?api[-_ ]?key|authorization|api[-_ ]?key|token)\s*[:=]\s*[^,;\s}]+/gi, '$1: [redacted]').slice(0, 600);
    throw new Error(`Seller API HTTP ${response.status}: ${safeBody}`);
  }
  if (!data) throw new Error(`Seller API HTTP ${response.status}: Invalid JSON response`);
  return data;
}

function normalizeKey(item, index) {
  const createdAt = Number(item.created_at || 0) * 1000;
  const expiresAt = Number(item.expires_at || 0) * 1000 || null;
  const devices = Array.isArray(item.devices) ? item.devices : [];
  let status = item.status || (item.enabled === false ? 'disabled' : 'pending');
  if (item.enabled === false) status = 'disabled';
  return {
    id: `seller_${item.key || index}`,
    key: item.key,
    status,
    duration: Number(item.duration || 0),
    maxDevices: Number(item.max_devices || 1),
    devices: Number(item.devices_used || devices.length),
    hwid: devices[0]?.device_id || '',
    createdAt,
    expiresAt,
    note: item.note || '',
    createdBy: state.sellerOwnership?.[item.key] || null,
    tags: [],
    lastSeen: devices[0]?.last_seen ? Number(devices[0].last_seen) * 1000 : null,
    server: devices[0]?.profile_server || '—',
    sellerDevices: devices
  };
}

export async function syncSellerData() {
  const first = await call('key/list?limit=500&offset=0');
  const rows = [...(first.keys || [])];
  if (Number(first.total || rows.length) > rows.length) {
    const second = await call(`key/list?limit=500&offset=${rows.length}`);
    rows.push(...(second.keys || []));
  }
  state.keys = rows.map(normalizeKey);
  state.devices = state.keys.flatMap((key) => (key.sellerDevices || []).map((device, index) => ({
    id: `seller_device_${key.id}_${index}`,
    hwid: device.device_id,
    key: key.key,
    server: device.profile_server || '—',
    bound: Number(device.bound_at || 0) * 1000,
    lastSeen: Number(device.last_seen || 0) * 1000,
    profile: device.profile_server || '—'
  })));
  state.sellerStats = first.stats || {};
  state.sellerLive = true;
  save();
  return state.sellerStats;
}

export async function createSellerKeys({ duration, maxDevices, quantity, prefix, note }) {
  const result = await call('key/create', { method: 'POST', body: JSON.stringify({ duration, max_devices: maxDevices, quantity, prefix, note }) });
  const created = (result.keys || result.created || result.created_keys || []).map((item, index) => typeof item === 'string' ? { key: item } : normalizeKey(item, index));
  created.forEach((item) => { if (item.key) state.sellerOwnership[item.key] = state.admin.user; });
  save();
  await syncSellerData();
  return created;
}

export async function sellerAction(action, payload) {
  const result = await call(`key/${action}`, { method: 'POST', body: JSON.stringify(payload) });
  await syncSellerData();
  return result;
}
