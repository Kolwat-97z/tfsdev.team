/* Static admin console + server-side Seller API proxy. */
import { createServer } from 'node:http';
import { readFile, stat, writeFile } from 'node:fs/promises';
import { extname, join, normalize, resolve } from 'node:path';

const PORT = Number(process.env.PORT) || 3000;
const ROOT = resolve(process.cwd(), 'public');
const CONFIG_PATH = resolve(process.cwd(), 'seller-api.config.json');
const SELLER = JSON.parse(await readFile(CONFIG_PATH, 'utf8'));
const ALLOWED = new Set(['stats', 'presets', 'key/list', 'key/create', 'key/info', 'key/extend', 'key/reset', 'key/toggle', 'key/delete', 'key/set_note']);
const TYPES = { '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.mjs':'text/javascript; charset=utf-8', '.json':'application/json; charset=utf-8', '.png':'image/png', '.jpg':'image/jpeg', '.svg':'image/svg+xml', '.webp':'image/webp', '.ico':'image/x-icon', '.woff2':'font/woff2' };

const maskKey = (key) => (key ? `${key.slice(0, 10)}…${key.slice(-4)}` : '');
async function sellerConfig(req, res) {
  if (req.method === 'GET') return json(res, 200, { status: 'success', baseUrl: SELLER.baseUrl, apiKey: maskKey(SELLER.apiKey) });
  if (req.method !== 'POST') return json(res, 405, { status: 'error', message: 'Method not allowed' });
  const body = await readBody(req);
  const apiKey = String(body.apiKey || '').trim();
  if (!/^az_[A-Za-z0-9]{20,}$/.test(apiKey)) return json(res, 400, { status: 'error', message: 'API key ต้องขึ้นต้นด้วย az_ และมีความยาวอย่างน้อย 23 ตัวอักษร' });
  let live = false;
  let message = '';
  try {
    const probe = await fetch(`${SELLER.baseUrl.replace(/\/$/, '')}/stats`, { headers: { 'X-API-Key': apiKey, Accept: 'application/json' } });
    live = probe.ok;
    if (!probe.ok) {
      message = `Seller API ปฏิเสธคีย์นี้ (HTTP ${probe.status})`;
      if (probe.status === 401 || probe.status === 403) return json(res, 400, { status: 'error', message });
    }
  } catch (error) {
    message = `ตรวจสอบคีย์กับ Seller API ไม่ได้: ${error.message}`;
  }
  await writeFile(CONFIG_PATH, `${JSON.stringify({ ...SELLER, apiKey }, null, 2)}\n`, 'utf8');
  SELLER.apiKey = apiKey;
  return json(res, 200, { status: 'success', baseUrl: SELLER.baseUrl, apiKey: maskKey(apiKey), live, message });
}
function json(res, code, payload) { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(JSON.stringify(payload)); }
async function readBody(req) { const chunks = []; for await (const chunk of req) chunks.push(chunk); const text = Buffer.concat(chunks).toString('utf8'); return text ? JSON.parse(text) : {}; }
async function sellerProxy(req, res, url) {
  const path = url.pathname.replace(/^\/api\/seller\/?/, '').replace(/\/$/, '');
  if (!ALLOWED.has(path)) return json(res, 404, { status: 'error', message: 'Seller endpoint is not enabled' });
  const target = new URL(`${SELLER.baseUrl.replace(/\/$/, '')}/${path}`);
  if (req.method === 'GET') url.searchParams.forEach((value, key) => target.searchParams.set(key, value));
  const requestedKey = String(req.headers['x-seller-api-key'] || '').trim();
  const apiKey = requestedKey.startsWith('az_') ? requestedKey : SELLER.apiKey;
  const init = { method: req.method, headers: { 'X-API-Key': apiKey, Accept: 'application/json' } };
  if (req.method !== 'GET') { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(await readBody(req)); }
  const upstream = await fetch(target, init);
  const text = await upstream.text();
  res.writeHead(upstream.status, { 'Content-Type': upstream.headers.get('content-type') || 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(text);
}

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const apiPath = url.pathname.slice(url.pathname.indexOf('/api/seller/'));
    if (url.pathname.includes('/api/seller/')) {
      const apiUrl = new URL(url);
      apiUrl.pathname = apiPath;
      return await sellerProxy(req, res, apiUrl);
    }
    if (url.pathname.endsWith('/api/seller-config')) return await sellerConfig(req, res);
    const rawPath = decodeURIComponent(url.pathname);
    const candidates = [rawPath, rawPath.replace(/^\/[^/]+(?=\/)/, '')];
    const requested = candidates.find((candidate) => candidate === '/' || candidate.startsWith('/assets/') || candidate === '/index.html') || rawPath;
    const safe = normalize(requested).replace(/^(\.\.[/\\])+/, '');
    let filePath = join(ROOT, safe);
    let info = await stat(filePath).catch(() => null);
    if (info?.isDirectory()) { filePath = join(filePath, 'index.html'); info = await stat(filePath).catch(() => null); }
    if (!info) { filePath = join(ROOT, 'index.html'); info = await stat(filePath); }
    const body = await readFile(filePath);
    res.writeHead(200, { 'Content-Type': TYPES[extname(filePath).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
    res.end(body);
  } catch (error) {
    json(res, 502, { status: 'error', message: error.message });
  }
});
server.listen(PORT, '0.0.0.0', () => console.log(`Strange Wair admin console listening on http://0.0.0.0:${PORT}`));
