แพ็กเกจติดตั้ง TFS - RESELLER STRANGT WIRE สำหรับ cPanel Node.js

Application root: โฟลเดอร์ที่มี package.json และ server.mjs
Startup file: server.mjs
Node.js: 20.x หรือ 22.x
Mode: Production

โครงสร้างสำคัญ:
- package.json, server.mjs, seller-api.config.json อยู่ระดับเดียวกัน
- public/index.html และ public/assets อยู่ใน public
- ห้ามย้าย seller-api.config.json เข้า public
- หากติดตั้งที่ Application URL path เช่น /reseller ให้เปิดเว็บที่ /reseller/ และโค้ดรองรับ API/assets ใต้ path นี้
- ไม่ต้องอัปโหลด node_modules และไม่ต้อง npm install เพราะไม่มี dependency ภายนอก
- Notification settings ในรุ่นนี้เป็นการตั้งค่าฝั่ง browser/localStorage; การใช้งาน production จริงควรย้าย webhook/token ไป backend ที่ปลอดภัย
